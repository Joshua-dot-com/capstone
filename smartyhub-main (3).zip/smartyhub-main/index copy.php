<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub - Your Adventure in Learning!</title>
    <link rel="stylesheet" href="assets/style/index.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <?php include "base/header-script.php" ?>
    
</head>

<body>
    <nav>
        <div class="container">
            <div class="header">
                <h4 class="animate__animated animate__bounce">SmartyHub</h4>
            </div>
            <div class="buttons">
                <a href="login.php" class="btn login-btn animate__animated animate__pulse">Let's Go!</a>
                <a href="registration.php" class="btn register-btn animate__animated animate__pulse">Join the Fun!</a>
            </div>
        </div>
    </nav>

    <div class="image-container">
        <img src="assets/images/index-image.png" alt="index" class="index-img animate__animated animate__fadeIn">
        <p class="quote animate__animated animate__slideInUp">SmartyHub: Where curiosity meets knowledge, and learning
            becomes an adventure!</p>
    </div>

    <div class="content-container">
        <div class="info-section animate__animated animate__fadeIn">
            <img src="assets/images/about us.jpg" alt="About Us">
            <div class="info-text">
                <h3>About Us</h3>
                <p>SmartyHub is your ticket to an amazing learning adventure! We make learning super fun and easy for
                    awesome kids like you!</p>
            </div>
        </div>

        <div class="info-section right-image animate__animated animate__fadeIn">
            <img src="assets/images/contact us.jpg" alt="Contact Us">
            <div class="info-text">
                <h3>Contact Us</h3>
                <p>Email: fun@smartyhub.com</p>
                <p>Phone: (123) FUN-LEARN</p>
                <p>Address: 123 Cool School Street, Brainville, SM 12345</p>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-container">
            <img src="assets/images/footer.gif" alt="Footer" class="animate__animated animate__fadeIn">
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.3.0/sweetalert2.all.min.js"></script>
    <script>
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('success') === '1') {
            Swal.fire({
                title: 'Woohoo!',
                text: 'You\'re now part of the SmartyHub family!',
                icon: 'success',
                confirmButtonText: 'Let\'s Learn!',
                confirmButtonColor: '#4CAF50'
            });
        }
    </script>
</body>

</html>