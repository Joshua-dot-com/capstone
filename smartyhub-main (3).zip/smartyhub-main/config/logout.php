<?php
// Start the session if it hasn't been started already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";

/**
 * Function to securely log out a user
 */
function secureLogout() {
    // Unset all session variables
    $_SESSION = array();

    // If it's desired to kill the session, also delete the session cookie.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Destroy the session
    session_destroy();

    // Clear any remember-me cookies
    setcookie('remember_me', '', time() - 3600, '/', '', true, true);

    // Regenerate the session ID
    session_regenerate_id(true);

    // Redirect to login page
    $login_url = 'login.php'; // Adjust this to your login page URL
    header("Location: $login_url");
    exit();
}

// Check if logout was requested
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    secureLogout();
} else {
    // If logout wasn't explicitly requested, redirect to home page or show an error
    header("Location: ../index.php");
    exit();
}
?>