<?php
// Include the database connection file
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $bday = $_POST['bday'];
    $school = $_POST['school'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password
    $user_type = 'user';
    $status = 'inactive';

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO users (fname, mname, lname, bday, school, email, password, date_created, user_type, status, is_login) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, false)");

    // Bind parameters
    $stmt->bind_param("sssssssss", $fname, $mname, $lname, $bday, $school, $email, $password, $user_type, $status);

    // Execute the statement
    if ($stmt->execute()) {
        // Set a success flag in the URL
        header("Location: ../index.php?success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
}