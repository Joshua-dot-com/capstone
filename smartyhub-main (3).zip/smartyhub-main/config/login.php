<?php
// Start the session
session_start();

// Include the database connection file
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement
    $stmt = $conn->prepare("SELECT id, fname, password, user_type FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);

    // Execute the statement
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Bind result variables
        $stmt->bind_result($id, $fname, $hashed_password, $user_type);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Set session variables
            $_SESSION['id'] = $id;
            $_SESSION['fname'] = $fname;
            $_SESSION['user_type'] = $user_type;

            // Update is_login status
            $update_stmt = $conn->prepare("UPDATE users SET is_login = TRUE WHERE id = ?");
            $update_stmt->bind_param("i", $id);
            $update_stmt->execute();
            $update_stmt->close();

            // Check user type and redirect
            if ($user_type == 'admin') {
                header("Location: ../controllers/admin/admin-index.php");
            } else {
                header("Location: ../controllers/user/user-index.php");
            }
            exit();
        } else {
            echo "Incorrect password. Please try again.";
        }
    } else {
        echo "No user found with that email. Please try again.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>