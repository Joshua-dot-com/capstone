<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fun Login Page</title>
    <?php include "base/header-script.php" ?>
    <link rel="stylesheet" href="assets/style/login-design.css">
</head>

<body>
    <div class="container">
        <a href="index.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Home</a>

        <div class="login-container">
            <div class="img-container">
                <img src="assets/images/student.png" alt="Happy Student">
            </div>

            <div class="form-container">
                <h1>Welcome Back, Friend!</h1>
                <form action="config/login.php" method="POST">
                    <div class="form-group">
                        <label for="email">What's your email?</label>
                        <input type="email" name="email" id="email" placeholder="Your email address" required>
                    </div>

                    <div class="form-group">
                        <label for="password">What's your secret password?</label>
                        <input type="password" name="password" id="password" placeholder="Your secret password"
                            required>
                    </div>

                    <div class="button-container">
                        <button type="submit" class="btn-login">Let's Go!</button>
                        <a href="registration.php" class="btn-register">Join the Fun!</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
<?php include "base/footer-script.php" ?>

</html>