<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub - Your Adventure in Learning!</title>
    <link rel="stylesheet" href="assets/style/index.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <?php include "base/header-script.php" ?>
    <style>
        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
        }
    </style>
</head>

<body>
    <nav>
        <div class="container">
            <div class="header">
                <h4 class="animate__animated animate__bounce">SmartyHub</h4>
            </div>
        </div>
    </nav>

    <div class="image-container">
        <img src="assets/images/index-image.png" alt="index" class="index-img animate__animated animate__fadeIn">
        <p class="quote animate__animated animate__slideInUp">SmartyHub: Where curiosity meets knowledge, and learning
            becomes an adventure!</p>
    </div>

    <div class="nav-buttons">
        <button class="btn-info login-btn animate__animated animate__fadeInUp"
            onclick="window.location.href='login.php'">Let's Go!</button>
        <button class="btn-info register-btn animate__animated animate__fadeInUp animate__delay-1s"
            onclick="window.location.href='registration.php'">Join the Fun!</button>
        <button class="popular-btn btn-info animate__animated animate__fadeInUp animate__delay-2s"
            onclick="document.getElementById('popular-lessons').scrollIntoView({ behavior: 'smooth' })">
            Popular Lessons!
        </button>
        <button class="about-us btn-info animate__animated animate__fadeInUp animate__delay-3s"
            onclick="document.getElementById('about').scrollIntoView({ behavior: 'smooth' })">
            Who Are We?
        </button>
        <button class="contact-us btn-info animate__animated animate__fadeInUp animate__delay-4s"
            onclick="document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })">
            Let's Chat!
        </button>
    </div>

    <div id="popular-lessons" class="lessons-container">
        <div class="lessons-content">
            <div class="row popular-row">
                <div class="card lesson-1">
                    <div class="card-header">Card Header</div>
                    <div class="card-body">Body</div>
                </div>
                <div class="card lesson-2">
                    <div class="card-header">Card Header</div>
                    <div class="card-body">Body</div>
                </div>
                <div class="card lesson-3">
                    <div class="card-header">Card Header</div>
                    <div class="card-body">Body</div>
                </div>
            </div>
        </div>
    </div>

    <div id="about" class="about-container">
        <div class="about-content">
            <img src="assets/images/about.png" alt="about" class="about-img animate__animated animate__fadeInLeft">
            <div class="about-text">
                <h3>About Us</h3>
                <p class="quote animate__animated animate__fadeInRight">
                    SmartyHub is your ticket to an amazing learning adventure! We make learning super fun and easy for
                    awesome kids like you!
                </p>
            </div>
        </div>
    </div>

    <div id="contact" class="contact-container">
        <div class="contact-content">
            <div class="contact-text">
                <h3>Contact Us</h3>
                <p class="quote animate__animated animate__fadeInRight">Email: fun@smartyhub.com</p>
                <p class="quote animate__animated animate__fadeInRight">Phone: (123) FUN-LEARN</p>
                <p class="quote animate__animated animate__fadeInRight">Address: 123 Cool School Street, Brainville, SM
                    12345</p>
            </div>
            <img src="assets/images/contact.png" alt="contact"
                class="contact-img animate__animated animate__fadeInLeft">
        </div>
    </div>

</body>

</html>