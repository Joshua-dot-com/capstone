<!-- Left Panel -->
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="admin-index.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                </li>

                <li>
                    <a href="admin-users.php"> <i class="menu-icon fa fa-users"></i>Users </a>
                </li>

                <li class="menu-title">Manage Study</li>
                <li>
                    <a href="admin-grades.php"> <i class="menu-icon fa fa-calendar-alt"></i>Grade Level </a>
                </li>

                <li>
                    <a href="admin-subjects.php"> <i class="menu-icon fa fa-calendar-alt"></i>Subjects </a>
                </li>

                <li>
                    <a href="admin-lessons.php"> <i class="menu-icon fa fa-file-alt"></i>Lessons </a>
                </li>

                <li>
                    <a href="admin-units.php"> <i class="menu-icon fa fa-file-alt"></i>Units </a>
                </li>

                <li>
                    <a href="admin-quizes.php"> <i class="menu-icon fa fa-file-alt"></i>Quizzes </a>
                </li>

                <li>
                    <a href="admin-word-test.php"> <i class="menu-icon fa fa-file-alt"></i>Word Test </a>
                </li>

                <li class="menu-title">Manage Reports</li>

                <li>
                    <a href="#"> <i class="menu-icon fa fa-users"></i>Reports </a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>
<!-- /#left-panel -->
<!-- Right Panel -->
<div id="right-panel" class="right-panel">
    <!-- Header-->
    <header id="header" class="header">
        <div class="top-left">
            <div class="navbar-header">
                <!-- <a class="navbar-brand" href="./"><img src="../../assets/images/puzzle logo.png" alt="Logo"></a> -->
                <a class="navbar-brand" href="./">LOGO</a>
                <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
            </div>
        </div>
        <div class="top-right">
            <div class="header-menu">
                <!-- <div class="header-left">
                    <button class="search-trigger"><i class="fa fa-search"></i></button>
                    <div class="form-inline">
                        <form class="search-form">
                            <input class="form-control mr-sm-2" type="text" placeholder="Search ..."
                                aria-label="Search">
                            <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                        </form>
                    </div>
                </div> -->

                <div class="user-area dropdown float-right">
                    <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <img class="user-avatar rounded-circle" src="../../assets/images/default-profile.png"
                            alt="User Avatar">
                    </a>

                    <div class="user-menu dropdown-menu">
                        <a class="nav-link" href="../../config/logout.php"><i class="fa fa-power -off"></i>Logout</a>
                    </div>
                </div>

            </div>
        </div>
    </header>
    <!-- /#header -->