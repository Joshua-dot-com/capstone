<?php include('config/fetch-quiz.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quizes</title>
    <?php include("base/header.php"); ?>
    <link rel="stylesheet" href="assets/style/css/table-users-design.css">
    <style>
        .btn-modal {
            font-weight: bold;
            color: white;
            border: none;
            padding: 3px 10px 3px 10px;
            border-radius: 7px;
        }

        .quizbtn {
            background-color: #FF6600;
        }

        .quizbtn:hover {
            background-color: #FC865A;
        }

        .unitbtn {
            background-color: #604CC3;
        }

        .unitbtn:hover {
            background-color: #4F75FF;
        }
    </style>
</head>

<body>
    <?php include("base/nav-header.php"); ?>
    <?php include("includes/quiz.php"); ?>
    <?php include "includes/modals/quiz-management/add-quiz.php"; ?>
    <?php include("base/nav-footer.php"); ?>
    <?php include("base/footer.php"); ?>
</body>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php
        if (isset($_SESSION['subject_message'])) {
            if ($_SESSION['subject_message'] === 'success') {
                echo "
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Subject added successfully.',
                });
                ";
            } elseif ($_SESSION['subject_message'] === 'error') {
                echo "
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred while adding the subject.',
                });
                ";
            }
            // Clear the message from the session
            unset($_SESSION['subject_message']);
        }
        ?>

        // Fetch subjects when grade is selected
        document.getElementById('gradeId').addEventListener('change', function () {
            const gradeId = this.value;

            // Clear the previous options
            document.getElementById('subjectId').innerHTML = '<option>Select Subject</option>';
            document.getElementById('lessonId').innerHTML = '<option>Select Lesson</option>';
            document.getElementById('step2').classList.add('hidden');
            document.getElementById('step3').classList.add('hidden');

            if (gradeId) {
                fetchSubjects(gradeId);
            }
        });

        // Fetch lessons when subject is selected
        document.getElementById('subjectId').addEventListener('change', function () {
            const subjectId = this.value;

            // Clear the previous lesson options
            document.getElementById('lessonId').innerHTML = '<option>Select Lesson</option>';
            document.getElementById('step3').classList.add('hidden');

            if (subjectId) {
                fetchLessons(subjectId);
            }
        });

        // Function to fetch subjects via AJAX
        function fetchSubjects(gradeId) {
            console.log("Grade ID: ", gradeId);
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'config/get_subjects.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('subjectId').innerHTML = xhr.responseText;
                    document.getElementById('step2').classList.remove('hidden');
                }
            };
            xhr.send('gradeId=' + gradeId);
        }

        // Function to fetch lessons via AJAX
        function fetchLessons(subjectId) {
            console.log("Subject ID: ", subjectId);
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'config/get_lessons.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('lessonId').innerHTML = xhr.responseText;
                    document.getElementById('step3').classList.remove('hidden');
                }
            };
            xhr.send('subjectId=' + subjectId);
        }
    });
</script>

</html>