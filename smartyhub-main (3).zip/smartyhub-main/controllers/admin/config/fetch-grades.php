<?php
require_once "../../config/db.php";
$sql = "SELECT * FROM grades";
$result = $conn->query($sql);

