<?php
require_once "../../config/db.php";
$sql = "SELECT * FROM subjects";
$result = $conn->query($sql);
