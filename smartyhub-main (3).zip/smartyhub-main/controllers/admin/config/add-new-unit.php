<?php

// Include the database configuration file
include('../../../config/db.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Retrieve form data
    $lesson_id = mysqli_real_escape_string($conn, $_POST['lesson_id']);
    $unit_name = mysqli_real_escape_string($conn, $_POST['unit_name']);
    $unit_order = mysqli_real_escape_string($conn, $_POST['unit_order']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $media_type = mysqli_real_escape_string($conn, $_POST['media_type']);

    // Handle file upload
    $media_url = '';
    if (isset($_FILES['media_url']) && $_FILES['media_url']['error'] == 0) {
        // Set upload directory based on media type
        $upload_dir = '../../media/unit-lessons/';
        
        // Check if the directory exists, if not, create it
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Get the file name and set the target file path
        $file_name = basename($_FILES['media_url']['name']);
        $target_file = $upload_dir . $file_name;

        // Validate media type based on the selected option
        $file_type = mime_content_type($_FILES['media_url']['tmp_name']);

        // Set allowed mime types based on media type
        $allowed_mime_types = [];
        if ($media_type === 'image') {
            $allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif'];
        } elseif ($media_type === 'audio') {
            $allowed_mime_types = ['audio/mpeg', 'audio/wav', 'audio/mp3'];
        } elseif ($media_type === 'video') {
            $allowed_mime_types = ['video/mp4', 'video/avi', 'video/mpeg'];
        }

        // Check if the uploaded file type matches the allowed types
        if (in_array($file_type, $allowed_mime_types)) {
            // Move uploaded file to the specified directory
            if (move_uploaded_file($_FILES['media_url']['tmp_name'], $target_file)) {
                $media_url = 'media/unit-lessons/' . $file_name;
            } else {
                $_SESSION['subject_message'] = 'error_upload';
                header("Location: ../admin-units.php");
                exit();
            }
        } else {
            $_SESSION['subject_message'] = 'error_invalid_media';
            header("Location: ../admin-units.php");
            exit();
        }
    }

    // Check if the lesson_id exists in the lessons table
    $check_query = "SELECT * FROM lessons WHERE lesson_id = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($check_stmt, "i", $lesson_id);
    mysqli_stmt_execute($check_stmt);
    mysqli_stmt_store_result($check_stmt);

    if (mysqli_stmt_num_rows($check_stmt) == 0) {
        $_SESSION['subject_message'] = 'error_invalid_lesson';
        header("Location: ../admin-units.php");
        exit();
    }
    mysqli_stmt_close($check_stmt);

    // Determine the status based on unit_order
    $status = ($unit_order == 1) ? 'unlock' : 'lock';

    // Prepare the SQL query to insert unit data
    $query = "INSERT INTO units (lesson_id, unit_name, unit_order, description, media_type, media_url, status) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Prepare and bind the statement
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "isissss", $lesson_id, $unit_name, $unit_order, $description, $media_type, $media_url, $status);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['subject_message'] = 'success';
    } else {
        $_SESSION['subject_message'] = 'error';
        error_log("MySQL Error: " . mysqli_error($conn));
    }

    // Close statement
    $stmt->close();

    // Redirect back to the main page
    header("Location: ../admin-units.php");
    exit();

} else {
    echo "Invalid request method";
}

// Close the connection
mysqli_close($conn);
?>
