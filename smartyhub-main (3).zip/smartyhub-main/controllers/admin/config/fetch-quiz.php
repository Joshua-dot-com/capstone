<?php
require_once "../../config/db.php";

// SQL query to fetch quizes with corresponding subject names
$sql = "
    SELECT quizes.quiz_id, quizes.question, quizes.option_1, quizes.option_2, quizes.option_3, quizes.option_4, quizes.correct_answer, quizes.media_type, quizes.media_url, quizes.lesson_id, lessons.lesson_name 
    FROM quizes
    INNER JOIN lessons ON quizes.lesson_id = lessons.lesson_id
";

$result = $conn->query($sql);
?>
