<?php
require_once "../../config/db.php";

// SQL query to fetch quizes with corresponding subject names
$sql = "
    SELECT word_test.id, word_test.wav_file, word_test.word, word_test.date, lessons.lesson_name 
    FROM word_test
    INNER JOIN lessons ON word_test.lesson_id = lessons.lesson_id
";

$result = $conn->query($sql);
?>
