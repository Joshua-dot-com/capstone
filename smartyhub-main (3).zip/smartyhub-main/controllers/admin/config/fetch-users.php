<?php
require_once "../../config/db.php";
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
