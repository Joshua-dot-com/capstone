<?php
include_once "../../../config/db.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['grade_id'])) {
    $grade_id = $_GET['grade_id'];
} else {
    echo json_encode(['error' => 'Missing grade_id']);
    exit();
}

$query = "SELECT subject_id, subject_name FROM subjects WHERE grade_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $grade_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch subjects']);
    exit();
}

$subjects = [];
while ($row = mysqli_fetch_assoc($result)) {
    $subjects[] = $row;
}

header('Content-Type: application/json'); // Ensure JSON response header
echo json_encode($subjects);
?>