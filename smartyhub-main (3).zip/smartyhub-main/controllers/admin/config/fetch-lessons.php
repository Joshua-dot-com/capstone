<?php
require_once "../../config/db.php";

// SQL query to fetch lessons with corresponding subject names
$sql = "
    SELECT lessons.lesson_id, lessons.lesson_order, lessons.lesson_name, lessons.subject_id, subjects.subject_name 
    FROM lessons
    INNER JOIN subjects ON lessons.subject_id = subjects.subject_id
";

$result = $conn->query($sql);
?>
