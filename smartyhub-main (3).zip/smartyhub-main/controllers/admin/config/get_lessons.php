<?php
include_once "../../../config/db.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['subject_id'])) {
    $subject_id = $_GET['subject_id'];
} else {
    echo json_encode(['error' => 'Missing subject_id']);
    exit();
}

$query = "SELECT lesson_id, lesson_name FROM lessons WHERE subject_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $subject_id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch lessons']);
    exit();
}

$lessons = [];
while ($row = mysqli_fetch_assoc($result)) {
    $lessons[] = $row;
}

header('Content-Type: application/json'); // Ensure JSON response header
echo json_encode($lessons);
?>