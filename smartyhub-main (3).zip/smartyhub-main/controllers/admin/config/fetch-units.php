<?php
require_once "../../config/db.php";

// SQL query to fetch units with corresponding subject names
$sql = "
    SELECT units.unit_id, units.unit_name, units.unit_order, units.description, units.lesson_id, lessons.lesson_name 
    FROM units
    INNER JOIN lessons ON units.lesson_id = lessons.lesson_id
";

$result = $conn->query($sql);
?>
