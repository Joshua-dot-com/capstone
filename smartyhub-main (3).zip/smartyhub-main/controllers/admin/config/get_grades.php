<?php
include_once "../../../config/db.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$query = "SELECT grade_id, grade_name FROM grades";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch grades']);
    exit();
}

$grades = [];
while ($row = mysqli_fetch_assoc($result)) {
    $grades[] = $row;
}

header('Content-Type: application/json'); // Ensure JSON response header
echo json_encode($grades);
?>