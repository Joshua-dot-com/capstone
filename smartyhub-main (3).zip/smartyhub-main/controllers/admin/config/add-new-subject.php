<?php
session_start();
// Database connection parameters
require_once "../../../config/db.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $subject_name = $_POST['subject_name'];
    $grade_id = $_POST['grade_id'];
    $date_created = date('Y-m-d H:i:s');
    $media_url = ''; // Initialize media_url as empty string

    // Handle file upload
    if (isset($_FILES['media_url']) && $_FILES['media_url']['error'] == 0) {
        // Set upload directory
        $upload_dir = '../../media/subject-images/';
        
        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Get file information
        $file_name = basename($_FILES['media_url']['name']);
        $target_file = $upload_dir . $file_name;
        $file_type = mime_content_type($_FILES['media_url']['tmp_name']);

        // Define allowed file types
        $allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif'];

        // Check if the uploaded file type is allowed
        if (in_array($file_type, $allowed_mime_types)) {
            // Move uploaded file to the specified directory
            if (move_uploaded_file($_FILES['media_url']['tmp_name'], $target_file)) {
                // Save the relative path for the database
                $media_url = 'media/subject-images/' . $file_name;
            } else {
                $_SESSION['subject_message'] = 'error_upload';
                header("Location: ../admin-subjects.php");
                exit();
            }
        } else {
            $_SESSION['subject_message'] = 'error_invalid_media';
            header("Location: ../admin-subjects.php");
            exit();
        }
    }

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO subjects (subject_name, grade_id, media_url, date_created) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $subject_name, $grade_id, $media_url, $date_created);

    if ($stmt->execute()) {
        $_SESSION['subject_message'] = 'success';
    } else {
        $_SESSION['subject_message'] = 'error';
        error_log("Database Error: " . $stmt->error); // Log the error for debugging
    }

    $stmt->close();
    header("Location: ../admin-subjects.php");
    exit();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}

$conn->close();
?>