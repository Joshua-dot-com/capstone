<?php
// Include database connection
require_once("../../../config/db.php");
require_once("functions/sanitize.php");

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $id = sanitize_input($_POST['id']);
    $fname = sanitize_input($_POST['fname']);
    $mname = sanitize_input($_POST['mname']);
    $lname = sanitize_input($_POST['lname']);
    $bday = sanitize_input($_POST['bday']);
    $school = sanitize_input($_POST['school']);
    $email = sanitize_input($_POST['email']);
    $user_type = sanitize_input($_POST['user_type']);
    $status = sanitize_input($_POST['status']);

    // Check if user exists
    $query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch current user data
        $user = $result->fetch_assoc();

        // Check if any data has changed
        if (
            $user['fname'] != $fname || 
            $user['mname'] != $mname || 
            $user['lname'] != $lname || 
            $user['bday'] != $bday || 
            $user['school'] != $school || 
            $user['email'] != $email 
        ) {
            // Update user data
            $update_query = "UPDATE users SET fname = ?, mname = ?, lname = ?, bday = ?, school = ?, email = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("ssssssi", $fname, $mname, $lname, $bday, $school, $email, $id);

            if ($update_stmt->execute()) {
                // Redirect to the users table page
                header("Location: ../admin-users.php?success=1");
                exit();
            } else {
                echo "Error updating user information.";
            }
        } else {
            echo "No changes detected.";
        }
    } else {
        echo "User not found.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
