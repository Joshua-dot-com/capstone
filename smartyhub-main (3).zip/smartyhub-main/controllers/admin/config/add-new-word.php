<?php
// Include the database configuration file
include('../../../config/db.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $lesson_id = mysqli_real_escape_string($conn, $_POST['lesson_id']);
    $word = mysqli_real_escape_string($conn, $_POST['word']);

    // Handle file upload
    $wav_file = '';
    if (isset($_FILES['wav_file']) && $_FILES['wav_file']['error'] == 0) {
        $upload_dir = '../../media/unit-word/';

        // Check and create directory
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                die("Error creating upload directory.");
            }
        }

        $file_name = basename($_FILES['wav_file']['name']);
        $target_file = $upload_dir . $file_name;

        // Validate file type
        $file_type = mime_content_type($_FILES['wav_file']['tmp_name']);
        $allowed_mime_types = ['audio/wav', 'audio/mpeg']; // Support WAV and MP3

        if (in_array($file_type, $allowed_mime_types)) {
            if (move_uploaded_file($_FILES['wav_file']['tmp_name'], $target_file)) {
                $wav_file = 'media/unit-word/' . $file_name; // Save relative path
            } else {
                die("Error moving uploaded file. Check file permissions.");
            }
        } else {
            die("Invalid file type. Only MP3 and WAV files are allowed.");
        }
    } else {
        die("File upload error. Error code: " . $_FILES['wav_file']['error']);
    }

    // Insert data into the database
    $query = "INSERT INTO word_test (lesson_id, wav_file, word, date) VALUES (?, ?, ?, NOW())";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "iss", $lesson_id, $wav_file, $word);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['subject_message'] = 'success';
    } else {
        error_log("MySQL Error: " . mysqli_error($conn));
        die("Database error: " . mysqli_error($conn));
    }

    mysqli_stmt_close($stmt);
    header("Location: ../admin-word-test.php");
    exit();
} else {
    die("Invalid request method.");
}

mysqli_close($conn);
