<?php
session_start();
// Database connection parameters
require_once "../../../config/db.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $subject_id = $_POST['subject_id'];         // Subject ID from the form
    $lesson_order = $_POST['lesson_order'];     // Lesson order from the form
    $lesson_name = $_POST['lesson_name'];       // Lesson name from the form
    $date_created = date('Y-m-d H:i:s');        // Current date and time

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO lessons (lesson_name, subject_id, lesson_order, date_created) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siis", $lesson_name, $subject_id, $lesson_order, $date_created); // "siis" for string, integer, integer, string

    // Execute the statement
    if ($stmt->execute()) {
        // Set success message in session
        $_SESSION['lesson_message'] = 'success';
    } else {
        // Set error message in session
        $_SESSION['lesson_message'] = 'error';
    }

    // Close statement
    $stmt->close();

    // Redirect back to the main page
    header("Location: ../admin-lessons.php");
    exit();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}

// Close connection
$conn->close();
?>
