<?php
session_start();
// Database connection parameters
require_once "../../../config/db.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $grade_name = $_POST['grade_name'];
    $date_created = date('Y-m-d H:i:s'); // Current date and time

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO grades (grade_name, date_created) VALUES (?, ?)");
    $stmt->bind_param("ss", $grade_name, $date_created);

    if ($stmt->execute()) {
        // Set success message in session
        $_SESSION['subject_message'] = 'success';
    } else {
        // Set error message in session
        $_SESSION['subject_message'] = 'error';
    }

    // Close statement
    $stmt->close();

    // Redirect back to the main page
    header("Location: ../admin-grades.php");
    exit();
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method"]);
}

// Close connection
$conn->close();
?>
