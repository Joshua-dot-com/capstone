<?php
// Include database connection
require_once("../../../../config/db.php");
require_once("sanitize.php");

// Function to delete a record from a given table
function deleteRecord($table, $id) {
    global $conn;

    // Sanitize inputs
    $table = sanitize_input($table);
    $id = sanitize_input($id);

    // Validate that the table name is allowed
    $allowed_tables = ['users', 'another_table']; // Add more table names as needed
    if (!in_array($table, $allowed_tables)) {
        echo "Invalid table name.";
        return;
    }

    // Prepare the DELETE query
    $query = "DELETE FROM `$table` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        echo "Error preparing statement.";
        return;
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo "Record deleted successfully.";
    } else {
        echo "Error deleting record.";
    }

    // Close the statement
    $stmt->close();
}

// Check if the delete request was made
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['table']) && isset($_POST['id'])) {
    $table = $_POST['table'];
    $id = $_POST['id'];
    deleteRecord($table, $id);
}

$conn->close();
?>
