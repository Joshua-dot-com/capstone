<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Subjects Table</strong>
                        <button data-toggle="modal" data-target="#addSubjectModal" class="btn-modal subjectbtn" style="float: right;">Add Subject</button>
                    </div>
                    <div class="table-stats order-table ov-h" id="subject-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>ID</th>
                                    <th>Grade</th>
                                    <th>Subject</th>
                                    <!-- <th>Actions</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    $serial = 1;
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td class='serial'>" . $serial++ . ".</td>";
                                        echo "<td> SUB-ID-" . $row["subject_id"] . " </td>";
                                        echo "<td> <span class='description'>" . $row["grade_id"] . "</span> </td>";
                                        echo "<td> <span class='name'>" . $row["subject_name"] . "</span> </td>";

                                        // echo "<td>";
                                        // // Comment out the button div and its contents
                                
                                        // echo "<div class='btn-div'>";
                                        // echo "<button class='btn btn-sm view-btn' 
                                        // data-id='" . $row["id"] . "' 
                                        // data-toggle='modal' 
                                        // data-target='#userViewModal'>View</button>";

                                        // echo "<button class='btn btn-sm update-btn' 
                                        // data-userid='" . $row["id"] . "' 
                                        // data-toggle='modal' 
                                        // data-target='#userUpdateModal'>Update</button>";

                                        // echo "<button class='btn btn-sm delete-btn' data-table='users' data-id='" . $row["id"] . "'>Delete</button>";
                                        // echo "</div>";

                                        // echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9'>No records found</td></tr>";
                                }
                                $conn->close();

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
