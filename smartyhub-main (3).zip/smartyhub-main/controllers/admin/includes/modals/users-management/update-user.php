<div class="modal fade" id="userUpdateModal" tabindex="-1" role="dialog" aria-labelledby="userUpdateModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="config/update-user-info.php" method="post">
                <div class="modal-body">
                    <input type="text" id="updateId" name="id" class="form-control" hidden>

                    <div class="user-info text-center">
                        <img src="../../assets/images/default-profile.png" alt="Profile"
                            class="user-image rounded-circle">
                        <div class="status-tags">
                            <span class="badge-status" id="userstatus"></span>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-4">
                            <label for="firstName" class="font-weight-bold label">First Name</label>
                            <input type="text" id="firstName" name="fname" class="form-control ">
                        </div>
                        <div class="col-md-4">
                            <label for="middleName" class="font-weight-bold label">Middle Name</label>
                            <input type="text" id="middleName" name="mname" class="form-control ">
                        </div>
                        <div class="col-md-4">
                            <label for="lastName" class="font-weight-bold label">Last Name</label>
                            <input type="text" id="lastName" name="lname" class="form-control ">
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md">
                            <label for="updateEmail" class="font-weight-bold label">Email</label>
                            <input type="email" id="updateEmail" name="email" class="form-control">
                        </div>
                        <div class="col-md">
                            <label for="updateBday" class="font-weight-bold label">Birthday</label>
                            <input type="date" id="updateBday" name="bday" class="form-control">
                        </div>

                        <div class="col-md">
                            <label for="updateAgency" class="font-weight-bold label">Agency</label>
                            <input type="text" id="updateAgency" name="school" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="submit-btn">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>