<div class="modal fade" id="userViewModal" tabindex="-1" role="dialog" aria-labelledby="userViewModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="user-info text-center">
                    <img src="../../assets/images/default-profile.png" alt="Profile" class="user-image rounded-circle">
                    <h2 id="userName"></h2>
                    <div class="user-tags">
                        <span class="badge-designation" id="userStatus"></span>
                        <span class="badge-role" id="user_role"></span>
                    </div>
                </div>
                <br>
                <ul class="nav nav-tabs justify-content-center" id="userTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="info-tab" data-toggle="tab" href="#info" role="tab">INFO</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" id="activity-tab" data-toggle="tab" href="#activity" role="tab">ACTIVITY</a>
                    </li> -->
                </ul>
                <div class="tab-content" id="userTabContent">
                    <br>
                    <div class="tab-pane fade show active" id="info" role="tabpanel">
                        <div class="container">
                            <div class="row">
                                <div class="col-md">
                                    <label for="userEmail" class="font-weight-bold">Email</label>
                                    <span id="userEmail" class="form-control"></span>
                                </div>
                                <div class="col-md">
                                    <label for="userBday" class="font-weight-bold">Birthday</label>
                                    <span id="userBday" class="form-control"></span>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md">
                                    <label for="userAgency" class="font-weight-bold">Agency</label>
                                    <span id="userAgency" class="form-control"></span>
                                </div>
                                <div class="col-md">
                                    <label for="userRegistered" class="font-weight-bold">Registered</label>
                                    <span id="userRegistered" class="form-control"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="tab-pane fade" id="activity" role="tabpanel">
                        <ul class="activity-list">
                            <div class="container activity-container">
                                <div class="row align-items-center justify-content-end">
                                    <div class="col-5">
                                        <div class="circle-icon">
                                            <i class="pe-7s-medal icons"></i>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="info-container">
                                            <span id="userScore"></span>
                                            <span class="text-below">Score</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row align-items-center justify-content-end">
                                    <div class="col-5">
                                        <div class="circle-icon">
                                            <i class="pe-7s-joy icons"></i>
                                        </div>
                                    </div>
                                    <div class="col-5">
                                        <div class="info-container">
                                            <span id="userGame"></span>
                                            <span class="text-below">Game</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</div>