<div class="modal fade" id="addwordModal" tabindex="-1" role="dialog" aria-labelledby="addwordModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Word Test</h4>
            </div>
            <form id="wordForm" action="config/add-new-word.php" method="POST" enctype="multipart/form-data">
                <!-- Added enctype -->
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md">
                            <label for="lesson_id" class="font-weight-bold">Lesson:</label>
                            <select name="lesson_id" id="lesson_id" class="form-control" required>
                                <option value="" disabled>Select Grade Level</option>
                                <?php
                                // Connect to the database
                                include('../../config/db.php');

                                // Fetch the lesson from the lessons table
                                $query = "SELECT lesson_id, lesson_name FROM lessons";
                                $result = mysqli_query($conn, $query);

                                // Loop through each result and create an option element
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<option value="' . $row['lesson_id'] . '">' . $row['lesson_name'] . '</option>';
                                }

                                // Close the database connection
                                mysqli_close($conn);
                                ?>
                            </select>
                        </div>


                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="wav_file" class="font-weight-bold">Wav File:</label>
                            <input type="file" name="wav_file" id="wav_file" class="form-control" accept="audio/*">
                        </div>
                        <div class="col-md">
                            <label for="word" class="font-weight-bold">Word</label>
                            <input type="text" id="word" name="word" class="form-control"
                                placeholder="Please insert the corresponding word." required>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>