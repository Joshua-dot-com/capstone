<div class="modal fade" id="addLessonModal" tabindex="-1" role="dialog" aria-labelledby="addSubjectModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Subject</h4>
            </div>
            <form id="addSubjectForm" action="config/add-new-lesson.php" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="subjectLevel" class="font-weight-bold">Subject:</label>
                        <select class="form-control" id="subjectLevel" name="subject_id" required>
                            <option value="">Select Subject</option>
                            <?php
                            // Connect to the database
                            include('../../config/db.php');

                            // Fetch the subject levels from the subjects table
                            $query = "SELECT subject_id, subject_name FROM subjects";
                            $result = mysqli_query($conn, $query);

                            // Loop through each result and create an option element
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="' . $row['subject_id'] . '">' . $row['subject_name'] . '</option>';
                            }

                            // Close the database connection
                            mysqli_close($conn);
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="lessonOrder" class="font-weight-bold label">Lesson Order:</label>
                        <input class="form-control" type="text" id="lessonOrder" name="lesson_order" required placeholder="Please input the Sequence(#) of the lesson.">
                    </div>

                    <div class="form-group">
                        <label for="lessonName" class="font-weight-bold">Lesson:</label>
                        <input class="form-control" type="text" id="lessonName" name="lesson_name" required placeholder="Lesson Title">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" aria-label="Close">
                        Close
                    </button>
                    <button type="submit">Add Subject</button>
                </div>
            </form>
        </div>
    </div>
</div>