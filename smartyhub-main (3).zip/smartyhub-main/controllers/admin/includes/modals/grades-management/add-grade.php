<div class="modal fade" id="addGradeModal" tabindex="-1" role="dialog" aria-labelledby="addSubjectModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Grade Level</h4>
            </div>
            <form action="config/add-grade-level.php" method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md">
                            <label for="gradeLevel" class="font-weight-bold label">Grade Level:</label>
                            <input class="form-control " type="text" id="gradeLevel" name="grade_name" required>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" data-dismiss="modal" aria-label="Close">
                        Close
                    </button>
                    <button type="submit">Submit</button>

                </div>
            </form>
        </div>
    </div>
</div>