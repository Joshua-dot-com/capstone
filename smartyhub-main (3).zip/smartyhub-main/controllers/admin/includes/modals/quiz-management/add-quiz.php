<div class="modal fade" id="addQuizModal" tabindex="-1" role="dialog" aria-labelledby="addQuizModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Quiz</h4>
            </div>
            <form id="quizForm" action="config/add-new-quiz.php" method="POST" enctype="multipart/form-data"> <!-- Added enctype -->
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="lesson_id" class="font-weight-bold">Lesson:</label>
                            <select name="lesson_id" id="lesson_id" class="form-control" required>
                                <option value="" disabled>Select Grade Level</option>
                                <?php
                                // Connect to the database
                                include('../../config/db.php');

                                // Fetch the lesson from the lessons table
                                $query = "SELECT lesson_id, lesson_name FROM lessons";
                                $result = mysqli_query($conn, $query);

                                // Loop through each result and create an option element
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo '<option value="' . $row['lesson_id'] . '">' . $row['lesson_name'] . '</option>';
                                }

                                // Close the database connection
                                mysqli_close($conn);
                                ?>
                            </select>
                        </div>

                        <div class="col-md">
                            <label for="question">Question</label>
                            <input type="text" id="question" name="question_text" class="form-control"
                                placeholder="Input Question" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="option1" class="font-weight-bold">First Option:</label>
                            <input type="text" id="option1" name="option_1" class="form-control"
                                placeholder="Please insert first option." required>
                        </div>

                        <div class="col-md">
                            <label for="option2" class="font-weight-bold">Second Option:</label>
                            <input type="text" id="option2" name="option_2" class="form-control"
                                placeholder="Please insert second option." required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="option3" class="font-weight-bold">Third Option:</label>
                            <input type="text" id="option3" name="option_3" class="form-control"
                                placeholder="Please insert third option." required>
                        </div>

                        <div class="col-md">
                            <label for="option4" class="font-weight-bold">Fourth Option:</label>
                            <input type="text" id="option4" name="option_4" class="form-control"
                                placeholder="Please insert fourth option." required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="correct_answer" class="font-weight-bold">Correct Answer:</label>
                            <input type="text" id="correct_answer" name="correct_answer" class="form-control"
                                placeholder="Please insert the correct answer." required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="media_type" class="font-weight-bold">Media Type:</label>
                            <select name="media_type" id="media_type" class="form-control">
                                <option value="" selected disabled>Select</option>
                                <option value="image">Image</option>
                                <option value="audio">Audio</option>
                                <option value="video">Video</option>
                            </select>
                        </div>

                        <div class="col-md">
                            <label for="media_url" class="font-weight-bold">Media File:</label>
                            <input type="file" name="media_url" id="media_url" class="form-control" accept="image/*,audio/*,video/*"> <!-- Accept all types -->
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
