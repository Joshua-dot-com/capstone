<!-- Your Modal -->
<div class="modal fade" id="addSubjectModal" tabindex="-1" role="dialog" aria-labelledby="addSubjectModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="addSubjectModalLabel">New Subject</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="addSubjectForm" action="config/add-new-subject.php" method="POST"  enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="subjectName" class="font-weight-bold">Subject Name:</label>
                        <input class="form-control" type="text" id="subjectName" name="subject_name" required>
                    </div>
                    <div class="form-group">
                        <label for="gradeLevel" class="font-weight-bold">Grade Level:</label>
                        <select class="form-control" id="gradeLevel" name="grade_id" required>
                            <option value="">Select Grade Level</option>
                            <?php
                            // Connect to the database
                            include('../../config/db.php');

                            // Fetch the grade levels from the grades table
                            $query = "SELECT grade_id, grade_name FROM grades";
                            $result = mysqli_query($conn, $query);

                            // Loop through each result and create an option element
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<option value="' . $row['grade_id'] . '">' . $row['grade_name'] . '</option>';
                            }

                            // Close the database connection
                            mysqli_close($conn);
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="subject_pic" class="font-weight-bold">Subject Image:</label>
                        <input type="file" name="media_url" id="subject_pic" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Subject</button>
                </div>
            </form>
        </div>
    </div>
</div>
