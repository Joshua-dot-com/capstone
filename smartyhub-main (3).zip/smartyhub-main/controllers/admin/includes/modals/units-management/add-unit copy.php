<div class="modal fade" id="addUnitModal" tabindex="-1" role="dialog" aria-labelledby="addUnitModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Unit</h4>
            </div>
            <form id="unitForm" action="#" method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="form-group">
                            <div class="col-md">
                                <!-- Step 1: Select Grade -->
                                <div id="step1">
                                    <div>
                                        <label for="gradeId"
                                            class="block text-sm font-medium text-gray-700 font-weight-bold">Grade
                                            Level:</label>
                                        <select id="gradeId" name="gradeId" required
                                            class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                            <!-- Options will be populated dynamically -->
                                            <option value="" disabled> Select Grade</option>
                                            <?php
                                            include('../../config/db.php');
                                            $query = "SELECT grade_id, grade_name FROM grades";
                                            $result = mysqli_query($conn, $query);
                                            while ($row = mysqli_fetch_assoc($result)) {

                                                echo '<option value="' . $row['grade_id'] . '">' . $row['grade_name'] . '</option>';
                                            }
                                            mysqli_close($conn);
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md">
                                <!-- Step 2: Select Subject -->
                                <div id="step2" class="hidden">
                                    <div>
                                        <label for="subjectId"
                                            class="block text-sm font-medium text-gray-700 font-weight-bold">Select
                                            Subject:</label>
                                        <select id="subjectId" name="subjectId" required
                                            class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                            <!-- Options will be populated dynamically -->
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md">
                                <!-- Step 3: Select Lesson -->
                                <div id="step3" class="hidden">
                                    <div>
                                        <label for="lessonId"
                                            class="block text-sm font-medium text-gray-700 font-weight-bold">Select
                                            Lesson:</label>
                                        <select id="lessonId" name="lessonId" required
                                            class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                            <!-- Options will be populated dynamically -->
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Unit Lesson Form -->
                <div id="unitLessonForm" class="hidden">
                    <div>
                        <label for="unitOrder" class="block text-sm font-medium text-gray-700">Unit Order:</label>
                        <input type="number" id="unitOrder" name="unitOrder" required
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="unitName" class="block text-sm font-medium text-gray-700">Unit Name:</label>
                        <input type="text" id="unitName" name="unitName" required
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="description" class="block text-sm font-medium text-gray-700">Description:</label>
                        <textarea id="description" name="description" rows="3"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                    </div>
                </div>


                <!-- Media Form -->
                <div id="mediaForm" class="hidden">
                    <div>
                        <label for="mediaType" class="block text-sm font-medium text-gray-700">Media Type:</label>
                        <select id="mediaType" name="mediaType" required
                            class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="image">Image</option>
                            <option value="video">Video</option>
                            <option value="audio">Audio</option>
                        </select>
                    </div>
                    <div>
                        <label for="mediaUrl" class="block text-sm font-medium text-gray-700">Media File:</label>
                        <input type="file" id="mediaUrl" name="mediaUrl" required
                            class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                </div>

                <!-- Submit Button -->
                <div>
                    <button type="submit" id="submitBtn"
                        class="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 hidden">
                        Submit
                    </button>
                </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        </form>
    </div>
</div>
</div>