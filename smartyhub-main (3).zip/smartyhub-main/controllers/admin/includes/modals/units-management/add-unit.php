<div class="modal fade" id="addUnitModal" tabindex="-1" role="dialog" aria-labelledby="addUnitModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4>New Unit</h4>
            </div>
            <form id="unitForm" action="config/add-new-unit.php" method="POST"  enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md">
                            <label for="grade_id" class="font-weight-bold">Grade Level:</label>
                            <select id="grade_id" class="form-control" required>
                                <option value="" selected disabled>Select Grade Level</option>
                                <!-- Options will be populated by JavaScript -->
                            </select>
                        </div>

                        <div class="col-md">
                            <label for="subject_id" class="font-weight-bold">Subject:</label>
                            <select id="subject_id" class="form-control" required>
                                <option value="" selected disabled>Select Subject</option>
                                <!-- Options will be populated by JavaScript -->
                            </select>
                        </div>

                        <div class="col-md">
                            <label for="lesson_id" class="font-weight-bold">Lesson:</label>
                            <select name="lesson_id" id="lesson_id" class="form-control" required>
                                <option value="" selected disabled>Select Lesson</option>
                                <!-- Options will be populated by JavaScript -->
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="unitOrder" class="font-weight-bold">Unit Sequence:</label>
                            <input type="number" id="unitOrder" name="unit_order" class="form-control"
                                placeholder="Please insert unit sequence (1, 2, 3, ...)" required>
                        </div>

                        <div class="col-md">
                            <label for="unitName" class="font-weight-bold">Unit Name:</label>
                            <input type="text" id="unitName" name="unit_name" class="form-control"
                                placeholder="Please input the unit name." required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="description" class="font-weight-bold">Description:</label>
                            <textarea class="form-control" name="description" id="description"
                                placeholder="Please input unit description." required></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md">
                            <label for="media_type" class="font-weight-bold">Media Type:</label>
                            <select name="media_type" id="media_type" class="form-control">
                                <option value="" selected disabled>Select</option>
                                <option value="image">Image</option>
                                <option value="audio">Audio</option>
                                <option value="video">Video</option>
                            </select>
                        </div>

                        <div class="col-md">
                            <label for="media_url" class="font-weight-bold">Media File:</label>
                            <input type="file" name="media_url" id="media_url" class="form-control"
                                accept="image/*,audio/*,video/*" placeholder="Please upload a file.">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>