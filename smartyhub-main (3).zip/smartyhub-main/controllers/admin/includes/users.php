<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Users Table</strong>
                    </div>
                    <div class="table-stats order-table ov-h">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Agency</th>
                                    <th>Role</th>
                                    <th>Date Created</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    $serial = 1;
                                    while ($row = $result->fetch_assoc()) {
                                        $fullName = $row["fname"] . " " . $row["lname"];
                                        echo "<tr>";
                                        echo "<td class='serial'>" . $serial++ . ".</td>";
                                        echo "<td> ID-" . $row["id"] . " </td>";
                                        echo "<td> <span class='name'>" . $fullName . "</span> </td>";
                                        echo "<td> <span class='school'>" . $row["school"] . "</span> </td>";
                                        echo "<td><span class='user_type'>" . $row["user_type"] . "</span></td>";
                                        echo "<td><span class='date_registered'>" . $row["date_created"] . "</span></td>";
                                        echo "<td>";
                                        echo "<div class='status-div'>";
                                        if ($row["status"] == "active") {
                                            echo "<span class='status status-active'></span> <span class='status-text-active'>Active</span>";
                                        } else if ($row["status"] == "deleted") {
                                            echo "<span class='status status-deleted'></span> <span class='status-text-deleted'>Deleted</span>";
                                        } else {
                                            echo "<span class='status status-inactive'></span> <span class='status-text-inactive'>Inactive</span>";
                                        }
                                        echo "</div>";
                                        echo "</td>";
                                        echo "<td>";
                                        // Comment out the button div and its contents
                                
                                        echo "<div class='btn-div'>";
                                        echo "<button class='btn btn-sm view-btn' 
                                        data-id='" . $row["id"] . "' 
                                        data-name='" . htmlspecialchars($fullName, ENT_QUOTES) . "' 
                                        data-midname='" . htmlspecialchars($row["mname"], ENT_QUOTES) . "'
                                        data-email='" . htmlspecialchars($row["email"], ENT_QUOTES) . "' 
                                        data-bday='" . htmlspecialchars($row["bday"], ENT_QUOTES) . "' 
                                        data-agency='" . htmlspecialchars($row["school"], ENT_QUOTES) . "' 
                                        data-registered='" . htmlspecialchars($row["date_created"], ENT_QUOTES) . "' 
                                        data-status='" . htmlspecialchars($row["status"], ENT_QUOTES) . "' 
                                        data-role='" . htmlspecialchars($row["user_type"], ENT_QUOTES) . "' 
                                        data-toggle='modal' 
                                        data-target='#userViewModal'>View</button>";

                                        echo "<button class='btn btn-sm update-btn' 
                                        data-userid='" . $row["id"] . "' 
                                        data-fullname='" . htmlspecialchars($fullName, ENT_QUOTES) . "' 
                                        data-midname='" . htmlspecialchars($row["mname"], ENT_QUOTES) . "' 
                                        data-useremail='" . htmlspecialchars($row["email"], ENT_QUOTES) . "' 
                                        data-userbday='" . htmlspecialchars($row["bday"], ENT_QUOTES) . "' 
                                        data-userschool='" . htmlspecialchars($row["school"], ENT_QUOTES) . "' 
                                        data-userregistered='" . htmlspecialchars($row["date_created"], ENT_QUOTES) . "' 
                                        data-userstatus='" . htmlspecialchars($row["status"], ENT_QUOTES) . "' 
                                        data-userrole='" . htmlspecialchars($row["user_type"], ENT_QUOTES) . "' 
                                        data-toggle='modal' 
                                        data-target='#userUpdateModal'>Update</button>";

                                        echo "<button class='btn btn-sm delete-btn' data-table='users' data-id='" . $row["id"] . "'>Delete</button>";
                                        echo "</div>";

                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9'>No records found</td></tr>";
                                }
                                $conn->close();

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "includes/modals/users-management/view-user.php";
include "includes/modals/users-management/update-user.php";
?>