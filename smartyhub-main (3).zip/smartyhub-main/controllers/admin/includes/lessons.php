<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Lessons Table</strong>
                        <button data-toggle="modal" data-target="#addLessonModal" class="btn-modal lessonbtn" style="float: right;">Add Lesson</button>
                    </div>
                    <div class="table-stats order-table ov-h" id="lesson-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Seq</th>
                                    <th>Lesson ID</th>
                                    <th>Subject</th> <!-- Updated column to display subject name -->
                                    <th>Lesson</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td> #-" . $row["lesson_order"] . " </td>";
                                        echo "<td> LES-ID-" . $row["lesson_id"] . " </td>";
                                        echo "<td>" . $row["subject_name"] . " </td>"; // Display subject name
                                        echo "<td>" . $row["lesson_name"] . " </td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4'>No records found</td></tr>";
                                }
                                $conn->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
