<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header" style="justify-content: space-between;">
                        <strong class="card-title">Word Test Table</strong>
                        <div class="buttons" style="float: right;">
                            <button id="openModal" data-toggle="modal" data-target="#addwordModal"
                                class="btn-modal wordbtn">
                                Word
                            </button>
                        </div>
                    </div>
                    <div class="table-stats order-table ov-h" id="unit-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>ID</th>
                                    <th>Lesson</th>
                                    <th>Word File</th>
                                    <th>Word</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    $serial = 1;
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td class='serial'>" . $serial++ . ".</td>";
                                        echo "<td> WORD-ID-" . $row["id"] . " </td>";
                                        echo "<td> <span class='description'>" . $row["lesson_name"] . "</span> </td>";
                                        echo "<td>
                                                                    <audio controls>
                                                                        <source src='" . "../" . $row["wav_file"] . "' type='audio/mpeg'>
                                                                        <source src='" . "../" . $row["wav_file"] . "' type='audio/wav'>
                                                                        Your browser does not support the audio element.
                                                                    </audio>
                                                                  </td>";
                                        echo "<td> <span class='name'>" . $row["word"] . "</span> </td>";
                                        echo "<td> <span class='name'>" . $row["date"] . "</span> </td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9'>No records found</td></tr>";
                                }
                                $conn->close();

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>