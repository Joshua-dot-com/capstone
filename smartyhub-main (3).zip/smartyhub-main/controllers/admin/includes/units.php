<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header" style="justify-content: space-between;">
                        <strong class="card-title">Units Table</strong>
                        <div class="buttons" style="float: right;">
                            <button id="openModal" data-toggle="modal" data-target="#addUnitModal" class="btn-modal unitbtn">
                                Unit Lesson
                            </button>
                        </div>
                    </div>
                    <div class="table-stats order-table ov-h" id="unit-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="serial">#</th>
                                    <th>ID</th>
                                    <th>Unit Name</th>
                                    <th>Unit Order</th>
                                    <th>Lesson</th>
                                    <th>Description</th>
                                    <!-- <th>Actions</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($result->num_rows > 0) {
                                    $serial = 1;
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td class='serial'>" . $serial++ . ".</td>";
                                        echo "<td> UNIT-ID-" . $row["unit_id"] . " </td>";
                                        echo "<td> <span class='description'>" . $row["unit_name"] . "</span> </td>";
                                        echo "<td> <span class='name'>" . $row["unit_order"] . "</span> </td>";
                                        echo "<td> <span class='name'>" . $row["lesson_name"] . "</span> </td>";
                                        echo "<td> <span class='name'>" . $row["description"] . "</span> </td>";

                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='9'>No records found</td></tr>";
                                }
                                $conn->close();

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>