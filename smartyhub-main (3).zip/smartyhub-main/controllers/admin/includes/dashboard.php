<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="card">
                <span>total grades</span>
            </div>

            <div class="card">
                <span>total subjects</span>
            </div>

            <div class="card">
                <span>total lessons</span>
            </div>
            
        </div>

        <div class="row">
            <div class="card">
                <span>leaderboards</span>
            </div>
        </div>
    </div>
</div>
