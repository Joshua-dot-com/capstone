<?php include('config/fetch-users.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <?php include("base/header.php"); ?>
    <link rel="stylesheet" href="assets/style/css/table-users-design.css">
</head>

<body>
    <?php include("base/nav-header.php"); ?>
    <?php include("includes/users.php"); ?>
    <?php include("base/nav-footer.php"); ?>
    <?php include("base/footer.php"); ?>
</body>

<script>
    $(document).ready(function () {
        $('.view-btn').click(function () {
            var id = $(this).data('id');
            var name = $(this).data('name');
            var middleName = $(this).data('midname');
            var email = $(this).data('email');
            var bday = $(this).data('bday');
            var agency = $(this).data('agency');
            var registered = $(this).data('registered');
            var status = $(this).data('status');
            var role = $(this).data('role');
            var roleCapitalized = role.charAt(0).toUpperCase() + role.slice(1);
            var game = $(this).data('game');
            var score = $(this).data('score');

            $('#userName').text(name);
            $('#userEmail').text(email);
            $('#userBday').text(bday);
            $('#userAgency').text(agency);
            $('#userRegistered').text(registered);
            $('#userStatus').text(status);
            $('#user_role').text(roleCapitalized);
            $('#userGame').text(game);
            $('#userScore').text(score);

            // You can add more fields as needed

            $('#userViewModal').modal('show');
        });
    });

    $(document).ready(function () {
        $('.update-btn').click(function () {
            var id = $(this).data('userid');
            var fullName = $(this).data('fullname');
            var middleName = $(this).data('midname');
            var email = $(this).data('useremail');
            var bday = $(this).data('userbday');
            var agency = $(this).data('userschool');
            var registered = $(this).data('userregistered');
            var status = $(this).data('userstatus');
            var role = $(this).data('userrole');
            var roleCapitalized = role.charAt(0).toUpperCase() + role.slice(1);

            // Split full name into first name and last name
            var name_parts = fullName.split(" ");
            var firstName = name_parts[0];
            var lastName = name_parts.length > 1 ? name_parts.slice(1).join(" ") : "";

            $('#firstName').val(firstName);
            $('#middleName').val(middleName);
            $('#lastName').val(lastName);
            $('#updateEmail').val(email);
            $('#updateAgency').val(agency);
            $('#updateBday').val(bday);
            $('#updateId').val(id);

            // Update status with appropriate classes and text
            if (status.toLowerCase() === 'active') {
                $('#userstatus').html("<span class='status status-active'></span> <span class='status-text-active'>Active</span>");
            } else {
                $('#userstatus').html("<span class='status status-inactive'></span> <span class='status-text-inactive'>Inactive</span>");
            }

            $('#userUpdateModal').modal('show');
        });
    });

    $(document).ready(function () {
        $('.delete-btn').click(function () {
            var userId = $(this).data('id'); // Adjust the data attribute as necessary
            var table = $(this).data('table'); // Adjust the data attribute as necessary

            console.log(userId);

            // Use SweetAlert2 for confirmation
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // AJAX request to delete the record
                    $.ajax({
                        url: 'config/functions/delete.php', // Adjust the path if necessary
                        type: 'POST',
                        data: { table: table, id: userId },
                        success: function (response) {
                            // Show success message with SweetAlert2
                            Swal.fire(
                                'Deleted!',
                                response,
                                'success'
                            ).then(() => {
                                // Optionally update the table or reload the page
                                location.reload();
                            });
                        },
                        error: function (xhr, status, error) {
                            console.error('Error deleting record:', error);
                            // Show error message with SweetAlert2
                            Swal.fire(
                                'Error!',
                                'Error deleting record. Please try again.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });


</script>

</html>