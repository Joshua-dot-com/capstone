<?php include('config/fetch-lessons.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lesson</title>
    <?php include("base/header.php"); ?>
    <link rel="stylesheet" href="assets/style/css/table-users-design.css">
    <style>
        .btn-modal {
            font-weight: bold;
            color: white;
            border: none;
            padding: 3px 10px 3px 10px;
            border-radius: 7px;
        }
        
        .lessonbtn {
            background-color: #604CC3;
        }

        .lessonbtn:hover {
            background-color: #4F75FF;
        }
    </style>
</head>

<body>
    <?php include("base/nav-header.php"); ?>
    <?php include("includes/lessons.php"); ?>
    <?php include "includes/modals/lessons-management/add-lesson.php"; ?>
    <?php include("base/nav-footer.php"); ?>
    <?php include("base/footer.php"); ?>
</body>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php
        if (isset($_SESSION['subject_message'])) {
            if ($_SESSION['subject_message'] === 'success') {
                echo "
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Subject added successfully.',
                });
                ";
            } elseif ($_SESSION['subject_message'] === 'error') {
                echo "
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred while adding the subject.',
                });
                ";
            }
            // Clear the message from the session
            unset($_SESSION['subject_message']);
        }
        ?>
    });
</script>

</html>