<?php
// Database connection
include '../../config/db.php';

// Fetch totals
$total_grades = $conn->query("SELECT COUNT(*) AS total FROM grades")->fetch_assoc()['total'];
$total_subjects = $conn->query("SELECT COUNT(*) AS total FROM subjects")->fetch_assoc()['total'];
$total_lessons = $conn->query("SELECT COUNT(*) AS total FROM lessons")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php include "base/header.php"; ?>
    <style>
        /* General Reset */
        body,
        html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }

        /* Container */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 20px auto;
        }

        /* Card Grid */
        .row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        /* Card */
        .card {
            flex: 1;
            min-width: 200px;
            max-width: calc(33% - 20px);
            background: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            border: 1px solid #e0e0e0;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
        }

        /* Card Text */
        .card span {
            font-size: 1.2rem;
            font-weight: bold;
            color: #5a5a5a;
        }

        /* Animation */
        .animated {
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .row {
                flex-direction: column;
            }

            .card {
                max-width: 100%;
            }
        }
    </style>
</head>

<body>
    <?php include "base/nav-header.php"; ?>

    <div class="container">


        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="card">
                        <span>Total Grades: <?php echo $total_grades; ?></span>
                    </div>

                    <div class="card">
                        <span>Total Subjects: <?php echo $total_subjects; ?></span>
                    </div>

                    <div class="card">
                        <span>Total Lessons: <?php echo $total_lessons; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "base/footer.php"; ?>
</body>

</html>