<?php include('config/fetch-units.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Units</title>
    <?php include("base/header.php"); ?>
    <link rel="stylesheet" href="assets/style/css/table-users-design.css">
    <style>
        .btn-modal {
            font-weight: bold;
            color: white;
            border: none;
            padding: 3px 10px 3px 10px;
            border-radius: 7px;
        }

        .quizbtn {
            background-color: #FF6600;
        }

        .quizbtn:hover {
            background-color: #FC865A;
        }

        .unitbtn {
            background-color: #604CC3;
        }

        .unitbtn:hover {
            background-color: #4F75FF;
        }
    </style>
</head>

<body>
    <?php include("base/nav-header.php"); ?>
    <?php include("includes/units.php"); ?>
    <?php include "includes/modals/units-management/add-unit.php"; ?>
    <?php include("base/nav-footer.php"); ?>
    <?php include("base/footer.php"); ?>
</body>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php
        if (isset($_SESSION['subject_message'])) {
            if ($_SESSION['subject_message'] === 'success') {
                echo "
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Subject added successfully.',
                });
                ";
            } elseif ($_SESSION['subject_message'] === 'error') {
                echo "
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred while adding the subject.',
                });
                ";
            }
            // Clear the message from the session
            unset($_SESSION['subject_message']);
        }
        ?>

        loadGradeLevels();

        // Load subjects when grade level changes
        document.getElementById('grade_id').addEventListener('change', function () {
            const gradeId = this.value;
            loadSubjects(gradeId);
        });

        // Load lessons when subject changes
        document.getElementById('subject_id').addEventListener('change', function () {
            const subjectId = this.value;
            loadLessons(subjectId);
        });
    });

    function loadGradeLevels() {
        fetch('config/get_grades.php')
            .then(response => response.json())
            .then(data => {
                let gradeSelect = document.getElementById('grade_id');
                gradeSelect.innerHTML = '<option value="" disabled selected>Select Grade Level</option>';
                data.forEach(grade => {
                    let option = document.createElement('option');
                    option.value = grade.grade_id;
                    option.textContent = grade.grade_name;
                    gradeSelect.appendChild(option);
                });
            });
    }

    function loadSubjects(gradeId) {
        fetch(`config/get_subjects.php?grade_id=${gradeId}`)
            .then(response => response.json())
            .then(data => {
                let subjectSelect = document.getElementById('subject_id');
                subjectSelect.innerHTML = '<option value="" disabled selected>Select Subject</option>';
                data.forEach(subject => {
                    let option = document.createElement('option');
                    option.value = subject.subject_id;
                    option.textContent = subject.subject_name;
                    subjectSelect.appendChild(option);
                });
            });
    }

    function loadLessons(subjectId) {
        fetch(`config/get_lessons.php?subject_id=${subjectId}`)
            .then(response => response.json())
            .then(data => {
                let lessonSelect = document.getElementById('lesson_id');
                lessonSelect.innerHTML = '<option value="" disabled selected>Select Lesson</option>';
                data.forEach(lesson => {
                    let option = document.createElement('option');
                    option.value = lesson.lesson_id;
                    option.textContent = lesson.lesson_name;
                    lessonSelect.appendChild(option);
                });
            });
    }
</script>

</html>