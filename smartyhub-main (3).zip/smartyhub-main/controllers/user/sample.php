<?php
// Include the database connection
require_once "../../config/db.php"; // Ensure $conn is a mysqli connection

// Get the subject_id and user_id dynamically
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
$user_id = isset($_SESSION['id']) ? intval($_SESSION['id']) : 0;

echo "User ID from session: " . (isset($_SESSION['id']) ? $_SESSION['id'] : 'Session ID not set') . "<br>";


// Initialize array for lessons and progress
$lessons = [];

try {
    // Fetch all lessons under the subject
    $lessonQuery = $conn->prepare("
        SELECT lesson_id, lesson_name
        FROM lessons
        WHERE subject_id = ?");
    $lessonQuery->bind_param("i", $subject_id);
    $lessonQuery->execute();
    $lessonResult = $lessonQuery->get_result();

    while ($lesson = $lessonResult->fetch_assoc()) {
        $lesson_id = $lesson['lesson_id'];

        // Fetch total and completed units for the lesson
        $unitQuery = $conn->prepare("
            SELECT COUNT(*) AS total_units,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_units
            FROM units
            WHERE lesson_id = ?");
        $unitQuery->bind_param("i", $lesson_id);
        $unitQuery->execute();
        $unitQuery->bind_result($totalUnits, $completedUnits);
        $unitQuery->fetch();
        $unitQuery->close();

        // Fetch total and completed quizzes for the lesson
        $quizQuery = $conn->prepare("
            SELECT COUNT(*) AS total_quizzes,
                   SUM(completed) AS completed_quizzes
            FROM user_quiz_progress
            WHERE user_id = ? AND quiz_id IN (SELECT quiz_id FROM quizes WHERE lesson_id = ?)");
        $quizQuery->bind_param("ii", $user_id, $lesson_id);
        $quizQuery->execute();
        $quizQuery->bind_result($totalQuizzes, $completedQuizzes);
        $quizQuery->fetch();
        $quizQuery->close();

        // Fetch total and completed word tests for the lesson
        $wordTestQuery = $conn->prepare("
            SELECT COUNT(*) AS total_word_test,
                   SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) AS completed_word_tests
            FROM user_word_test_progress
            WHERE user_id = ? AND word_test_id IN (SELECT id FROM word_test WHERE lesson_id = ?)");
        $wordTestQuery->bind_param("ii", $user_id, $lesson_id);
        $wordTestQuery->execute();
        $wordTestQuery->bind_result($totalWordTests, $completedWordTests);
        $wordTestQuery->fetch();
        $wordTestQuery->close();

        // Calculate progress percentage for the lesson
        $totalItems = $totalUnits + $totalQuizzes + $totalWordTests;
        $completedItems = $completedUnits + $completedQuizzes + $completedWordTests;
        $progressPercentage = $totalItems > 0 ? ($completedItems / $totalItems) * 100 : 0;

        // Add lesson progress to the array
        $lessons[] = [
            'lesson_name' => $lesson['lesson_name'],
            'progress' => round($progressPercentage, 2)
        ];

        echo "Lesson ID: $lesson_id<br>";
        echo "Total Units: $totalUnits, Completed Units: $completedUnits<br>";
        echo "Total Quizzes: $totalQuizzes, Completed Quizzes: $completedQuizzes<br>";
        echo "Total Word Tests: $totalWordTests, Completed Word Tests: $completedWordTests<br>";
        echo "Total Items: $totalItems, Completed Items: $completedItems, Progress: $progressPercentage%<br>";

    }
} catch (Exception $e) {
    // Handle errors
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lessons Progress</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .lesson-container {
            width: 100%;
            margin-bottom: 20px;
        }

        .progress-container {
            width: 100%;
            background-color: #ddd;
            border-radius: 10px;
            padding: 5px;
            margin: 5px 0;
        }

        .progress-bar {
            height: 20px;
            border-radius: 10px;
        }

        .lesson-title {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 5px;
        }
    </style>
</head>

<body>
    <h1>Lesson Progress for Subject ID: <?= $subject_id ?></h1>
    <?php foreach ($lessons as $lesson): ?>
        <div class="lesson-container">
            <div class="lesson-title"><?= htmlspecialchars($lesson['lesson_name']) ?></div>
            <div class="progress-container">
                <div class="progress-bar" style="width: <?= $lesson['progress'] ?>%; background-color: #4caf50;"></div>
            </div>
            <p><?= $lesson['progress'] ?>% Completed</p>
        </div>
    <?php endforeach; ?>
</body>

</html>