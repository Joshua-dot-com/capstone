<header>
    <div class="logo">SmartyHub</div>
    <nav>
        <a href="user-index.php" class="nav-btn" id="home-btn">Home</a>
        <a href="user-profile.php" class="nav-btn" id="prof-btn">Profile</a>
        <a href="user-ranking.php" class="nav-btn" id="ranking-btn">Leaderboards</a>
        <a href="#" class="nav-btn" id="contact-btn">Contact Us</a>
        <a href="#" id="logoutBtn" class="nav-btn">&#8599; Logout</a>
    </nav>
</header>



<script>
document.getElementById('logoutBtn').addEventListener('click', function(e) {
    e.preventDefault();
    Swal.fire({
        title: 'Are you sure?',
        text: "You will be logged out of your account.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../../config/logout.php';
        }
    });
});
</script>