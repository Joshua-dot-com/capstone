<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Lessons</title>
    <?php include "base/header.php"; ?>
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
    <link rel="stylesheet" href="assets/style/css/user-lessons.css">
    <style>
        .back-button-sub {
            display: inline-flex;
            align-items: center;
            background-color: #FFB703;
            color: #023047;
            text-decoration: none;
            font-size: 1.2em;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            margin-bottom: 12px;
        }

        .progress-container {
            width: 100%;
            background-color: #ddd;
            border-radius: 10px;
            margin: 10px 0;
        }

        .progress-bar {
            height: 20px;
            border-radius: 10px;
            background-color: #4caf50;
        }

        .lesson {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>

        <?php
        // Include the database connection
        require_once "../../config/db.php";

        // Get user and subject data
        $subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;
        $user_id = isset($_SESSION['id']) ? intval($_SESSION['id']) : 0;

        // Fetch subject and grade information
        $subject_query = "SELECT s.subject_name, g.grade_name, g.grade_id 
                  FROM subjects s 
                  JOIN grades g ON s.grade_id = g.grade_id 
                  WHERE s.subject_id = ?";
        $stmt = $conn->prepare($subject_query);
        $stmt->bind_param("i", $subject_id);
        $stmt->execute();
        $subject_result = $stmt->get_result();
        $subject_info = $subject_result->fetch_assoc();
        $grade_id = $subject_info['grade_id'];

        // Initialize lessons array
        $lessons = [];

        // Fetch all lessons under the subject
        $lessonQuery = $conn->prepare("
    SELECT lesson_id, lesson_name, lesson_order
    FROM lessons
    WHERE subject_id = ?");
        $lessonQuery->bind_param("i", $subject_id);
        $lessonQuery->execute();
        $lessonResult = $lessonQuery->get_result();

        while ($lesson = $lessonResult->fetch_assoc()) {
            $lesson_id = $lesson['lesson_id'];

            // Initialize default values for components
            $totalUnits = $completedUnits = 0;
            $totalQuizzes = $completedQuizzes = 0;
            $totalWordTests = $completedWordTests = 0;

            // Fetch total and completed units for the lesson
            $unitQuery = $conn->prepare("
        SELECT COUNT(*) AS total_units
        FROM units
        WHERE lesson_id = ?");
            $unitQuery->bind_param("i", $lesson_id);
            $unitQuery->execute();
            $unitQuery->bind_result($totalUnits);
            $unitQuery->fetch();
            $unitQuery->close();

            // Fetch completed units for the user
            $completedUnitQuery = $conn->prepare("
        SELECT COUNT(*) AS completed_units
        FROM user_unit_progress
        WHERE user_id = ? AND unit_id IN (SELECT unit_id FROM units WHERE lesson_id = ?) AND completed = 1");
            $completedUnitQuery->bind_param("ii", $user_id, $lesson_id);
            $completedUnitQuery->execute();
            $completedUnitQuery->bind_result($completedUnits);
            $completedUnitQuery->fetch();
            $completedUnitQuery->close();

            // Ensure null values are set to zero
            if ($totalUnits === null) {
                $totalUnits = 0;
            }
            if ($completedUnits === null) {
                $completedUnits = 0;
            }

            // Fetch total and completed quizzes for the lesson
            $quizQuery = $conn->prepare("
        SELECT COUNT(*) AS total_quizzes
        FROM quizes
        WHERE lesson_id = ?");
            $quizQuery->bind_param("i", $lesson_id);
            $quizQuery->execute();
            $quizQuery->bind_result($totalQuizzes);
            $quizQuery->fetch();
            $quizQuery->close();

            // Fetch completed quizzes for the user
            $completedQuizQuery = $conn->prepare("
        SELECT COUNT(*) AS completed_quizzes
        FROM user_quiz_progress
        WHERE user_id = ? AND quiz_id IN (SELECT quiz_id FROM quizes WHERE lesson_id = ?) AND completed = 1");
            $completedQuizQuery->bind_param("ii", $user_id, $lesson_id);
            $completedQuizQuery->execute();
            $completedQuizQuery->bind_result($completedQuizzes);
            $completedQuizQuery->fetch();
            $completedQuizQuery->close();

            // Ensure null values are set to zero
            if ($totalQuizzes === null) {
                $totalQuizzes = 0;
            }
            if ($completedQuizzes === null) {
                $completedQuizzes = 0;
            }

            // Fetch total and completed word tests for the lesson
            $wordTestQuery = $conn->prepare("
        SELECT COUNT(*) AS total_word_tests
        FROM word_test
        WHERE lesson_id = ?");
            $wordTestQuery->bind_param("i", $lesson_id);
            $wordTestQuery->execute();
            $wordTestQuery->bind_result($totalWordTests);
            $wordTestQuery->fetch();
            $wordTestQuery->close();

            // Fetch completed word tests for the user
            $completedWordTestQuery = $conn->prepare("
        SELECT COUNT(*) AS completed_word_tests
        FROM user_word_test_progress
        WHERE user_id = ? AND word_test_id IN (SELECT id FROM word_test WHERE lesson_id = ?) AND completed = 1");
            $completedWordTestQuery->bind_param("ii", $user_id, $lesson_id);
            $completedWordTestQuery->execute();
            $completedWordTestQuery->bind_result($completedWordTests);
            $completedWordTestQuery->fetch();
            $completedWordTestQuery->close();

            // Ensure null values are set to zero
            if ($totalWordTests === null) {
                $totalWordTests = 0;
            }
            if ($completedWordTests === null) {
                $completedWordTests = 0;
            }

            // Calculate progress percentage
            $totalItems = $totalUnits + $totalQuizzes + $totalWordTests;
            $completedItems = $completedUnits + $completedQuizzes + $completedWordTests;
            $progressPercentage = $totalItems > 0 ? ($completedItems / $totalItems) * 100 : 0;

            // Add lesson progress to the array
            $lessons[] = [
                'id' => $lesson_id,
                'name' => $lesson['lesson_name'],
                'order' => $lesson['lesson_order'],
                'progress' => round($progressPercentage, 2)
            ];
        }
        ?>

        <!-- Back button with grade_id parameter -->
        <a href="user-subjects.php?grade_id=<?php echo htmlspecialchars($grade_id); ?>" class="back-button-sub">
            <i class="fas fa-arrow-left"></i> Back to Subjects
        </a>

        <h1><?php echo htmlspecialchars($subject_info['grade_name']) . " - " . htmlspecialchars($subject_info['subject_name']); ?>
        </h1>

        <div class="lessons-container">
            <?php if (!empty($lessons)): ?>
                <?php foreach ($lessons as $lesson): ?>
                    <div class="lesson">
                        <a href="user-units.php?lesson_id=<?php echo htmlspecialchars($lesson['id']); ?>" class="link">
                            <i class="fas fa-book-open lesson-icon"></i>
                            <div class="progress-container">
                                <div class="progress-bar" style="width: <?= $lesson['progress'] ?>%;"></div>
                            </div>
                            <p>Lesson <?php echo htmlspecialchars($lesson['order']); ?>:
                                <?php echo htmlspecialchars($lesson['name']); ?>
                            </p>
                            <p><?= $lesson['progress'] ?>% Completed</p>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-lessons">
                    <p>No lessons available for this subject yet.</p>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <?php include "base/footer.php"; ?>
</body>

</html>