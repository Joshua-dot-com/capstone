<?php
// Enable debugging (for development only)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

require_once "../../../config/db.php";

// Sanitize input
$user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
$word_test_id = filter_var($_POST['word_test_id'], FILTER_VALIDATE_INT);
$completed = filter_var($_POST['completed'], FILTER_VALIDATE_INT);

// Validate input
if ($user_id === false || $word_test_id === false || $completed === false) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input data.']);
    exit;
}

try {
    // Prepare query to insert or update the progress
    $query = "
        INSERT INTO user_word_test_progress (user_id, word_test_id, completed, completed_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE completed = VALUES(completed), completed_at = VALUES(completed_at)";
    
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("iii", $user_id, $word_test_id, $completed);

    // Execute query
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Progress recorded successfully.']);
    } else {
        throw new Exception("Execution failed: " . $stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

// Close database connection
$conn->close();
