<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../../../config/db.php";

// Debug log function
function log_debug($message) {
    $log_file = __DIR__ . '/debug.log';
    file_put_contents($log_file, date("Y-m-d H:i:s") . " - " . $message . "\n", FILE_APPEND);
}

// Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);
log_debug("Received data: " . json_encode($data));

$user_id = isset($data['user_id']) ? intval($data['user_id']) : null;
$unit_id = isset($data['unit_id']) ? intval($data['unit_id']) : null;
$completed = 1; // Set to 1 for completion
$completed_at = date("Y-m-d H:i:s");

$response = [];

// Validate input data
if ($user_id && $unit_id) {
    log_debug("Valid user_id ($user_id) and unit_id ($unit_id)");

    // Prepare the query to insert or update the user's progress
    $query = "INSERT INTO user_unit_progress (user_id, unit_id, completed, completed_at)
              VALUES (?, ?, ?, ?)
              ON DUPLICATE KEY UPDATE completed = VALUES(completed), completed_at = VALUES(completed_at)";

    log_debug("Prepared query: $query");

    $stmt = $conn->prepare($query);
    if ($stmt) {
        // Bind parameters with appropriate data types
        $stmt->bind_param("iiis", $user_id, $unit_id, $completed, $completed_at);

        // Execute and check for success or errors
        if ($stmt->execute()) {
            $response['status'] = 'success';
            log_debug("Database insert/update successful for user_id ($user_id), unit_id ($unit_id)");
        } else {
            $response['status'] = 'error';
            $response['message'] = "Execution failed: " . $stmt->error;
            log_debug("Execution failed: " . $stmt->error);
        }

        $stmt->close();
    } else {
        $response['status'] = 'error';
        $response['message'] = "Preparation failed: " . $conn->error;
        log_debug("Preparation failed: " . $conn->error);
    }
} else {
    $response['status'] = 'error';
    $response['message'] = "Invalid user_id or unit_id.";
    log_debug("Invalid user_id or unit_id. Received user_id: $user_id, unit_id: $unit_id");
}

// Output the response and log it
echo json_encode($response);
log_debug("Response: " . json_encode($response));

$conn->close();
?>
