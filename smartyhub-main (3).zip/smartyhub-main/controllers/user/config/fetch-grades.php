<?php
require_once "../../config/db.php";

// Start session if not started yet
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['user_type'] !== 'user') {
    // Redirect to login page if not logged in or not a user
    header("Location: ../../login.php");
    exit();
}

// Fetch all grades from the database
$sql = "SELECT grade_id, grade_name FROM grades";
$result = $conn->query($sql);
$grades = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $grades[] = [
            'id' => $row['grade_id'],
            'name' => $row['grade_name']
        ];
    }
}

// Debugging to display fetched grades
// echo "<pre>";
// print_r($grades);
// echo "</pre>";
// ?>
