<?php
require_once "../../config/db.php";

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['user_type'] !== 'user') {
    // Redirect to login page if not logged in or not a user
    header("Location: ../../login.php");
    exit();
}

// Get subject_id from URL parameter
$subject_id = isset($_GET['subject_id']) ? intval($_GET['subject_id']) : 0;

if ($subject_id === 0) {
    // Handle invalid subject_id
    $lessons = [];
    $error = "Invalid subject ID";
} else {
    // Fetch lessons from the database based on the subject_id
    $sql = "SELECT 
                lesson_id,
                lesson_name,
                subject_id,
                lesson_order,
                date_created
            FROM lessons 
            WHERE subject_id = ?
            ORDER BY lesson_order ASC";  // Order by lesson_order to maintain sequence
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $subject_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $lessons = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $lessons[] = [
                'id' => $row['lesson_id'],
                'name' => $row['lesson_name'],
                'subject_id' => $row['subject_id'],
                'order' => $row['lesson_order'],
                'date_created' => $row['date_created']
            ];
        }
    }
    
    $stmt->close();
}


?>