<?php
require_once "../../config/db.php";

// Start session if not started yet
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['id']) || $_SESSION['user_type'] !== 'user') {
    // Redirect to login page if not logged in or not a user
    header("Location: ../../login.php");
    exit();
}

// Fetch subjects from the database based on the grade_id
$grade_id = isset($_GET['grade_id']) ? $_GET['grade_id'] : 1; // Default to grade 1 if not provided
$sql = "SELECT subject_id, subject_name, grade_id, media_url, date_created FROM subjects WHERE grade_id = $grade_id";
$result = $conn->query($sql);

// Debug SQL query execution
if (!$result) {
    // Debugging the SQL query - this will help you if there's an error with the query
    die("Error executing query: " . $conn->error);
}

$subjects = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $subjects[] = [
            'id' => $row['subject_id'],
            'name' => $row['subject_name'],
            'grade_id' => $row['grade_id'],
            'date_created' => $row['date_created'],
            'image' => '../'. $row['media_url'] // need to create this in the admin, to upload the image of each subjects
        ];
    }
}

// Debugging to display fetched data
// echo "<pre>";
// print_r($subjects);
// echo "</pre>";

// You can also add a conditional to check if there are subjects and display an appropriate message
// if (empty($subjects)) {
//     echo "<p>No subjects found for grade ID $grade_id.</p>";
// } else {
//     echo "<p>Subjects successfully fetched. Check the printed array above for details.</p>";
// }

?>
