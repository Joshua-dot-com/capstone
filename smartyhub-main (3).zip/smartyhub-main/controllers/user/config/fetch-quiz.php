<?php
// Include database connection
require_once "../../config/db.php";

// Retrieve and validate the lesson ID from the GET request
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : null;

if (!$lesson_id || !filter_var($lesson_id, FILTER_VALIDATE_INT)) {
    $error = "Invalid lesson ID.";
} else {
    // Fetch quizzes based on lesson_id
    $quiz_query = "
        SELECT quiz_id, question, option_1, option_2, option_3, option_4, correct_answer
        FROM quizes
        WHERE lesson_id = ?";
        
    $stmt = $conn->prepare($quiz_query);
    $stmt->bind_param("i", $lesson_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $quizzes = $result->fetch_all(MYSQLI_ASSOC); // Fetch all quizzes for this lesson
    } else {
        $error = "Error fetching quizzes.";
    }

    // Close statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>