<?php
// Include database connection
require_once "../../config/db.php";

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and has the appropriate user type
if (!isset($_SESSION['id']) || $_SESSION['user_type'] !== 'user') {
    header("Location: ../../login.php");
    exit();
}

// Initialize variables for error handling
$lesson_info = [];
$units = [];
$error = null;

// Retrieve and validate the lesson ID from the GET request
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : null;

if (!$lesson_id || !filter_var($lesson_id, FILTER_VALIDATE_INT)) {
    $error = "Invalid lesson ID.";
} else {
    // Fetch lesson, subject, and grade information, including subject_id
    $lesson_info_query = "
        SELECT l.lesson_name, s.subject_name, g.grade_name, s.subject_id
        FROM lessons AS l
        JOIN subjects AS s ON l.subject_id = s.subject_id
        JOIN grades AS g ON s.grade_id = g.grade_id
        WHERE l.lesson_id = ?";

    $lesson_stmt = $conn->prepare($lesson_info_query);
    $lesson_stmt->bind_param("i", $lesson_id);

    if ($lesson_stmt->execute()) {
        $result = $lesson_stmt->get_result();
        $lesson_info = $result->fetch_assoc();

        if (!$lesson_info) {
            $error = "Lesson information not found.";
        }
    } else {
        $error = "Error fetching lesson information.";
    }
    $lesson_stmt->close();

    // If lesson information was successfully retrieved, proceed to fetch units
    if (!$error) {
        // Fetch units information
        $units_query = "
            SELECT unit_id, unit_name, unit_order, description, media_type, media_url
            FROM units
            WHERE lesson_id = ?
            ORDER BY unit_order ASC";

        $units_stmt = $conn->prepare($units_query);
        $units_stmt->bind_param("i", $lesson_id);

        if ($units_stmt->execute()) {
            $result = $units_stmt->get_result();
            $units = $result->fetch_all(MYSQLI_ASSOC);

            // Prepend "../" to media_url for each unit without using reference
            foreach ($units as $key => $unit) {
                $units[$key]['media_url'] = "../" . $unit['media_url'];

                // Check if the unit has been completed by the user
                $unit_id = $unit['unit_id'];
                $unitCompletedQuery = $conn->prepare("
                    SELECT completed FROM user_unit_progress 
                    WHERE user_id = ? AND unit_id = ?");
                $unitCompletedQuery->bind_param("ii", $_SESSION['id'], $unit_id);
                $unitCompletedQuery->execute();
                $unitCompletedQuery->bind_result($completed);
                $unitCompletedQuery->fetch();
                $units[$key]['completed'] = $completed == 1 ? true : false;  // Add completion status to unit array (1 = completed, 0 = not completed)
                $unitCompletedQuery->close();
            }
        } else {
            $error = "Error fetching units.";
        }
        $units_stmt->close();

        // Check if word test for the lesson is completed by the user
        $wordTestCompletedQuery = $conn->prepare("
            SELECT completed FROM user_word_test_progress 
            WHERE user_id = ? AND word_test_id IN (SELECT id FROM word_test WHERE lesson_id = ?)");
        $wordTestCompletedQuery->bind_param("ii", $_SESSION['id'], $lesson_id);
        $wordTestCompletedQuery->execute();
        $wordTestCompletedQuery->bind_result($wordTestCompleted);
        $wordTestCompletedQuery->fetch();
        $lesson_info['word_test_completed'] = $wordTestCompleted == 1 ? true : false;  // Check if word test is completed (1 = completed)
        $wordTestCompletedQuery->close();

        // Check if quiz for the lesson is completed by the user
        $quizCompletedQuery = $conn->prepare("
            SELECT completed FROM user_quiz_progress 
            WHERE user_id = ? AND quiz_id IN (SELECT quiz_id FROM quizes WHERE lesson_id = ?)");
        $quizCompletedQuery->bind_param("ii", $_SESSION['id'], $lesson_id);
        $quizCompletedQuery->execute();
        $quizCompletedQuery->bind_result($quizCompleted);
        $quizCompletedQuery->fetch();
        $lesson_info['quiz_completed'] = $quizCompleted == 1 ? true : false;  // Check if quiz is completed (1 = completed)
        $quizCompletedQuery->close();
    }
}

// Close the connection after all operations are complete
$conn->close();
?>
