<?php
// Enable debugging (for development only)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

require_once "../../../config/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    $quiz_id = $input['quiz_id'];
    $completed = 1;
    $user_id = $_SESSION['id'] ?? null; // Retrieve user ID from session

    if (!$user_id || !$quiz_id || !isset($completed)) {
        echo json_encode(['success' => false, 'message' => 'Invalid input']);
        exit;
    }

    // Record the current timestamp
    $completed_at = date('Y-m-d H:i:s');

    // Insert data into the database
    $stmt = $conn->prepare("INSERT INTO user_quiz_progress (user_id, quiz_id, completed, completed_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $user_id, $quiz_id, $completed, $completed_at);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Progress saved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save progress']);
    }

    $stmt->close();
    $conn->close();
}
?>
