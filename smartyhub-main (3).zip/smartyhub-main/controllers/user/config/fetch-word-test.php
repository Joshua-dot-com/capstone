<?php
// Include database connection
require_once "../../config/db.php";

// Retrieve and validate the lesson ID from the GET request
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : null;

if (!$lesson_id || !filter_var($lesson_id, FILTER_VALIDATE_INT)) {
    $error = "Invalid lesson ID.";
    //echo $error; // Debug: Output error for clarity
    exit; // Stop further execution
} else {
    //echo "Lesson ID: " . $lesson_id . "<br>"; // Debug: Output lesson_id

    // Fetch word_test based on lesson_id
    $word_test_query = "
        SELECT id, wav_file, word
        FROM word_test
        WHERE lesson_id = ?";
        
    $stmt = $conn->prepare($word_test_query);

    if (!$stmt) {
        echo "Statement preparation failed: " . $conn->error; // Debug: Output SQL error
        exit;
    }

    $stmt->bind_param("i", $lesson_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $word_test = $result->fetch_all(MYSQLI_ASSOC); // Fetch all word_test for this lesson
        //echo "Fetched Words: <pre>" . print_r($word_test, true) . "</pre>"; // Debug: Output fetched data
    } else {
        $error = "Error fetching word_test: " . $stmt->error; // Debug: SQL execution error
        echo $error;
    }

    // Close statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>
