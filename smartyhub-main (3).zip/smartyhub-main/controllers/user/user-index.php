<?php include "config/fetch-grades.php" ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub</title>
    <?php include "base/header.php" ?>
    <link rel="stylesheet" href="assets/style/css/user-index.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php" ?>
        <div class="content-wrapper">
            <div class="img-container">
                <img src="assets/images/user-index-img.png" alt="User image" class="user-img">
            </div>
            <main class="grade-grid">
                <?php foreach ($grades as $grade): ?>
                    <a href="<?php echo 'user-subjects.php?grade_id=' . $grade['id']; ?>" class="grade-link">
                        <div class="grade-card">
                            <div class="grade-name"><?php echo htmlspecialchars($grade['name'], ENT_QUOTES); ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </main>
        </div>
        <div class="img-container-2">
            <div class="letter">
                <span class="letter-span">Your potential is limitless</span>
                <span class="letter-span">Every challenge makes you stronger</span>
                <span class="letter-span">Curiosity is your superpower</span>
            </div>
            <img src="assets/images/user-index-img-2.png" alt="User image" class="user-img-2">
        </div>
    </div>
</body>
<?php include "base/footer.php" ?>

</html>
