<?php

// Include database connection
include '../../config/db.php'; // Adjust this path as needed

// Check if user is logged in
if (!isset($_SESSION['id']) || $_SESSION['user_type'] !== 'user') {
    // Redirect to login page if not logged in or not a user
    header("Location: ../../login.php");
    exit();
}

// Fetch the logged-in user's data from the database
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['id']); // Use the session ID
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit;
}

// Close database connection for user query
$stmt->close();

// Function to fetch user's total progress per subject from the database
function fetchUserSubjectProgress($conn, $user_id)
{
    $progress = [];

    // SQL query to fetch all lessons under each subject
    $sql = "SELECT subjects.subject_id, subjects.subject_name, lessons.lesson_id, lessons.lesson_name
            FROM subjects
            LEFT JOIN lessons ON lessons.subject_id = subjects.subject_id";

    $result = $conn->query($sql);

    // Initialize progress array for each subject
    while ($row = $result->fetch_assoc()) {
        $subject_id = $row['subject_id'];
        $subject_name = $row['subject_name'];

        // Initialize counters
        $total_items = 0;
        $completed_items = 0;
        $total_units = 0;
        $total_quizzes = 0;
        $total_word_tests = 0;
        $completed_units = 0;
        $completed_word_tests = 0;
        $completed_quizzes = 0;

        // Fetch all lessons for the current subject
        $lesson_id = $row['lesson_id'];

        // Handle subjects with no lessons
        if (!$lesson_id) {
            $progress[$subject_name] = 0; // No lessons, set progress to 0%
            continue;
        }

        // Fetch total units, quizzes, and word tests for the lesson
        $unitQuery = $conn->prepare("SELECT COUNT(*) FROM units WHERE lesson_id = ?");
        $unitQuery->bind_param("i", $lesson_id);
        $unitQuery->execute();
        $unitQuery->bind_result($total_units);
        $unitQuery->fetch();
        $unitQuery->close();

        $quizQuery = $conn->prepare("SELECT COUNT(*) FROM quizes WHERE lesson_id = ?");
        $quizQuery->bind_param("i", $lesson_id);
        $quizQuery->execute();
        $quizQuery->bind_result($total_quizzes);
        $quizQuery->fetch();
        $quizQuery->close();

        $wordTestQuery = $conn->prepare("SELECT COUNT(*) FROM word_test WHERE lesson_id = ?");
        $wordTestQuery->bind_param("i", $lesson_id);
        $wordTestQuery->execute();
        $wordTestQuery->bind_result($total_word_tests);
        $wordTestQuery->fetch();
        $wordTestQuery->close();

        // Fetch completed units, quizzes, and word tests for the user
        $completedUnitQuery = $conn->prepare("SELECT COUNT(*) FROM user_unit_progress WHERE user_id = ? AND completed = 1 AND unit_id IN (SELECT unit_id FROM units WHERE lesson_id = ?)");
        $completedUnitQuery->bind_param("ii", $user_id, $lesson_id);
        $completedUnitQuery->execute();
        $completedUnitQuery->bind_result($completed_units);
        $completedUnitQuery->fetch();
        $completedUnitQuery->close();

        $completedQuizQuery = $conn->prepare("SELECT COUNT(*) FROM user_quiz_progress WHERE user_id = ? AND completed = 1 AND quiz_id IN (SELECT quiz_id FROM quizes WHERE lesson_id = ?)");
        $completedQuizQuery->bind_param("ii", $user_id, $lesson_id);
        $completedQuizQuery->execute();
        $completedQuizQuery->bind_result($completed_quizzes);
        $completedQuizQuery->fetch();
        $completedQuizQuery->close();

        $completedWordTestQuery = $conn->prepare("SELECT COUNT(*) FROM user_word_test_progress WHERE user_id = ? AND completed = 1 AND word_test_id IN (SELECT word_test_id FROM word_test WHERE lesson_id = ?)");
        $completedWordTestQuery->bind_param("ii", $user_id, $lesson_id);
        $completedWordTestQuery->execute();
        $completedWordTestQuery->bind_result($completed_word_tests);
        $completedWordTestQuery->fetch();
        $completedWordTestQuery->close();

        // Calculate totals
        $total_items += ($total_units + $total_quizzes + $total_word_tests);
        $completed_items += ($completed_units + $completed_quizzes + $completed_word_tests);
    }

    // Calculate progress percentage for the subject
    $progress_percentage = ($total_items > 0) ? round(($completed_items / $total_items) * 100) : 0;

    // Add subject progress to the array
    $progress[$subject_name] = $progress_percentage;

    return $progress;
}



// Fetch progress data from the database
$progress = fetchUserSubjectProgress($conn, $_SESSION['id']);

// Close the database connection
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <?php include "base/header.php" ?>
    <link rel="stylesheet" href="assets/style/css/user-prof.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>

        <main>
            <section class="profile-info">
                <img src="../../assets/images/default-profile.png" alt="Student Avatar" class="avatar">
                <div class="details">
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['fname'] . ' ' . $user['lname']); ?></p>
                    <p><strong>Birthdate:</strong> <?php echo htmlspecialchars($user['bday']); ?></p>
                    <p><strong>School:</strong> <?php echo htmlspecialchars($user['school']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                </div>
            </section>

            <section class="learning-progress">
                <h2>Learning Progress</h2>
                <div class="progress-table">
                    <?php if (!empty($progress)): ?>
                        <table class="progress-table">
                            <tr>
                                <th>Subject</th>
                                <th>Progress</th>
                            </tr>
                            <?php foreach ($progress as $subject => $percentage): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($subject); ?></td>
                                    <td><?php echo htmlspecialchars($percentage); ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php else: ?>
                        <p>No progress data available.</p>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
</body>
<?php include "base/footer.php" ?>

</html>