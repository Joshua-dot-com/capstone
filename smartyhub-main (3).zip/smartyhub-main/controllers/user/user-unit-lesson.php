<?php
require_once "../../config/db.php";

// Assuming you have user_id and unit_id from the session or GET parameters
$user_id = $_SESSION['id']; // Ensure user_id is set in session or replace as needed
$unit_id = isset($_GET['unit_id']) ? intval($_GET['unit_id']) : null;
$unit = null;

// Fetch the current unit details
if ($unit_id) {
    $query = "SELECT * FROM units WHERE unit_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $unit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $unit = $result->fetch_assoc();
    $stmt->close();
}

// Get the next unit details
$next_unit = null;
if ($unit) {
    $next_unit_query = "SELECT * FROM units WHERE lesson_id = ? AND unit_order = ?";
    $next_stmt = $conn->prepare($next_unit_query);
    $next_unit_order = $unit['unit_order'] + 1;
    $next_stmt->bind_param("ii", $unit['lesson_id'], $next_unit_order);
    $next_stmt->execute();
    $next_result = $next_stmt->get_result();
    $next_unit = $next_result->fetch_assoc();
    $next_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Unit Details</title>
    <?php include "base/header.php" ?>
    <link rel="stylesheet" href="assets/style/css/user-units.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>

        <main>
            <?php if ($unit): ?>
                <h1><?php echo htmlspecialchars($unit['unit_name']); ?></h1>
                <h2>Unit <?php echo htmlspecialchars($unit['unit_order']); ?> -
                    <?php echo htmlspecialchars($unit['description']); ?>
                </h2>

                <!-- Media Display -->
                <div class="media-content">
                    <?php if ($unit['media_type'] === 'image' && !empty($unit['media_url'])): ?>
                        <img src="<?php echo htmlspecialchars('../' . $unit['media_url']); ?>" alt="Unit Image"
                            style="width: 100%; height: auto;">
                        <!-- Finish Button for Image Type -->
                        <button id="finishButton" class="finish-button">Finish</button>
                    <?php elseif ($unit['media_type'] === 'video' && !empty($unit['media_url'])): ?>
                        <video id="lessonVideo" controls style="width: 100%; height: auto;">
                            <source src="<?php echo htmlspecialchars('../' . $unit['media_url']); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p class="error-message">The unit details could not be found. Please try again.</p>
            <?php endif; ?>
        </main>
    </div>

    <script>
        // JavaScript to handle the finish button for image-type units
        document.addEventListener("DOMContentLoaded", function () {
            const finishButton = document.getElementById("finishButton");
            if (finishButton) {
                finishButton.addEventListener("click", function () {
                    // AJAX request to mark the unit as completed
                    $.ajax({
                        url: "config/record-unit-progress.php",
                        method: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({
                            user_id: <?php echo json_encode($user_id); ?>,
                            unit_id: <?php echo json_encode($unit_id); ?>
                        }),
                        success: function (response) {
                            if (typeof response === "string") {
                                try {
                                    response = JSON.parse(response); // Convert to JSON if it's a string
                                } catch (e) {
                                    console.error("Error parsing response:", e);
                                }
                            }

                            if (response.status === "success") {
                                // Display a SweetAlert2 success alert before redirecting
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Congratulations!',
                                    text: 'You have successfully completed this unit.',
                                    confirmButtonText: 'Okay'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // Redirect to the next lesson or finish page
                                        window.location.href = "../user-units.php?lesson_id=<?php echo $unit['lesson_id']; ?>";
                                    }
                                });
                            } else {
                                console.error("Failed to mark the unit as completed:", response);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: 'Failed to mark the unit as completed. Please try again.'
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX request failed:", status, error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'An error occurred during the request. Please try again.'
                            });
                        }
                    });
                });
            }

            // JavaScript to handle video completion
            const lessonVideo = document.getElementById("lessonVideo");
            if (lessonVideo) {
                lessonVideo.addEventListener("ended", function () {
                    // AJAX request to mark the unit as completed
                    $.ajax({
                        url: "config/record-unit-progress.php",
                        method: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({
                            user_id: <?php echo json_encode($user_id); ?>,
                            unit_id: <?php echo json_encode($unit_id); ?>
                        }),
                        success: function (response) {
                            if (typeof response === "string") {
                                try {
                                    response = JSON.parse(response); // Convert to JSON if it's a string
                                } catch (e) {
                                    console.error("Error parsing response:", e);
                                }
                            }

                            if (response.status === "success") {
                                // Display a SweetAlert2 success alert
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Congratulations!',
                                    text: 'You have completed this unit.',
                                    confirmButtonText: '<?php echo $next_unit ? "Next Unit" : "Finish"; ?>'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        <?php if ($next_unit): ?>
                                            window.location.href = "user-unit-lesson.php?unit_id=<?php echo $next_unit['unit_id']; ?>";
                                        <?php else: ?>
                                            Swal.fire({
                                                icon: 'info',
                                                title: 'All units complete!',
                                                text: 'You have finished all units in this lesson.'
                                            });
                                        <?php endif; ?>
                                    }
                                });
                            } else {
                                console.error("Failed to mark the unit as completed:", response);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: 'Failed to mark the unit as completed. Please try again.'
                                });
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX request failed:", status, error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'An error occurred during the request. Please try again.'
                            });
                        }
                    });
                });
            }
        });

    </script>

    <?php include "base/footer.php"; ?>
</body>

</html>