<?php include "config/fetch-units.php" ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Units</title>
    <?php include "base/header.php" ?>
    <link rel="stylesheet" href="assets/style/css/user-units.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php" ?>

        <!-- Back button with subject_id parameter to redirect to lessons page -->
        <?php if (isset($lesson_info['subject_id'])): ?>
            <a href="user-lessons.php?subject_id=<?php echo htmlspecialchars($lesson_info['subject_id']); ?>"
                class="back-button">
                <i class="fas fa-arrow-left"></i> Back to Lessons
            </a>
        <?php endif; ?>

        <main>
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <p><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php else: ?>
                <h1><?php echo htmlspecialchars($lesson_info['grade_name']) . " - " .
                    htmlspecialchars($lesson_info['subject_name']); ?>
                    <span class="emoji">🧪🧬🔬</span>
                </h1>
                <h2><?php echo htmlspecialchars($lesson_info['lesson_name']); ?></h2>

                <div class="units-container">
                    <?php if (!empty($units)): ?>
                        <?php foreach ($units as $unit): ?>
                            <?php
                            // Determine if the unit is locked
                            $isLocked = $unit['completed'] ? 'locked' : '';
                            ?>
                            <a href="#" class="unit <?php echo $isLocked; ?>"
                                data-unit="<?php echo htmlspecialchars($unit['unit_id']); ?>">
                                <div class="book-icon">
                                    <img src="assets/images/book-unit.jpg" alt="Book" class="img-unit">
                                </div>
                                <p>Unit <?php echo htmlspecialchars($unit['unit_order']); ?></p>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No units available for this lesson.</p>
                    <?php endif; ?>
                </div>

                <div class="quiz-container">
                    <?php
                    // Determine if the word test is locked
                    $wordTestLocked = $lesson_info['word_test_completed'] ? 'locked' : '';
                    ?>
                    <a href="user-word-test.php?lesson_id=<?php echo htmlspecialchars($lesson_id); ?>"
                        class="word-test <?php echo $wordTestLocked; ?>">
                        <div class="book-icon">
                            <img src="assets/images/book-unit.jpg" alt="Book" class="img-unit">
                            <span class="lightbulb">💡</span>
                        </div>
                        <p>Word Test</p>
                    </a>

                    <?php
                    // Determine if the quiz is locked
                    $quizLocked = $lesson_info['quiz_completed'] ? 'locked' : '';
                    ?>
                    <a href="user-quiz.php?lesson_id=<?php echo htmlspecialchars($lesson_id); ?>"
                        class="quiz <?php echo $quizLocked; ?>">
                        <div class="book-icon">
                            <img src="assets/images/book-unit.jpg" alt="Book" class="img-unit">
                            <span class="lightbulb">💡</span>
                        </div>
                        <p>Quiz</p>
                    </a>
                </div>

            <?php endif; ?>
        </main>
    </div>

    <script>
        // Function to handle locked item click
        function handleLockedClick(e) {
            e.preventDefault();
            Swal.fire({
                icon: 'info',
                title: 'Item Locked',
                text: 'You have already completed this item.',
                confirmButtonText: 'OK'
            });
        }

        // Handle units
        const units = document.querySelectorAll('.unit');
        units.forEach(unit => {
            unit.addEventListener('click', (e) => {
                if (unit.classList.contains('locked')) {
                    handleLockedClick(e);
                } else {
                    // Redirect to user-unit-lesson.php with the unitId as a URL parameter
                    e.preventDefault();
                    const unitId = unit.getAttribute('data-unit');
                    window.location.href = `user-unit-lesson.php?unit_id=${unitId}`;
                }
            });
        });

        // Handle word tests
        const wordTests = document.querySelectorAll('.word-test');
        wordTests.forEach(wordTest => {
            wordTest.addEventListener('click', (e) => {
                if (wordTest.classList.contains('locked')) {
                    handleLockedClick(e);
                }
            });
        });

        // Handle quizzes
        const quizzes = document.querySelectorAll('.quiz');
        quizzes.forEach(quiz => {
            quiz.addEventListener('click', (e) => {
                if (quiz.classList.contains('locked')) {
                    handleLockedClick(e);
                }
            });
        });
    </script>

    <?php include "base/footer.php" ?>
</body>

</html>
