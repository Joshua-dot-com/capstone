<?php include "config/fetch-quiz.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Quiz</title>
    <?php include "base/header.php"; ?>
    <link rel="stylesheet" href="assets/style/css/user-quiz.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>

        <main>
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <p><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php elseif (!empty($quizzes)): ?>
                <h1 class="quiz-title">Quiz Time!</h1>
                <div class="quiz-container">
                    <?php foreach ($quizzes as $quiz): ?>
                        <div class="quiz-item" data-quiz-id="<?php echo htmlspecialchars($quiz['quiz_id']); ?>"
                            data-correct="<?php echo htmlspecialchars($quiz['correct_answer']); ?>">
                            <p class="question"><?php echo htmlspecialchars($quiz['question']); ?></p>
                            <div class="options">
                                <button class="option option-1"><?php echo htmlspecialchars($quiz['option_1']); ?></button>
                                <button class="option option-2"><?php echo htmlspecialchars($quiz['option_2']); ?></button>
                                <button class="option option-3"><?php echo htmlspecialchars($quiz['option_3']); ?></button>
                                <button class="option option-4"><?php echo htmlspecialchars($quiz['option_4']); ?></button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No quizzes available for this lesson.</p>
            <?php endif; ?>
        </main>
    </div>

    <!-- SweetAlert2 JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const quizItems = document.querySelectorAll('.quiz-item');
            let completedCount = 0; // Track how many quizzes have been completed correctly

            quizItems.forEach(quizItem => {
                const quizId = quizItem.getAttribute('data-quiz-id');
                const correctAnswer = quizItem.getAttribute('data-correct');

                quizItem.querySelectorAll('.option').forEach(optionButton => {
                    optionButton.addEventListener('click', () => {
                        const userAnswer = optionButton.textContent.trim();
                        const completed = userAnswer === correctAnswer ? 1 : 0;

                        // Display feedback to the user
                        Swal.fire({
                            title: completed ? '🎉 Great Job!' : 'Oops!',
                            text: completed ? 'You got it right!' : 'Try again!',
                            icon: completed ? 'success' : 'error',
                            confirmButtonText: completed ? 'Finish' : 'Retry'
                        }).then(() => {
                            if (completed) {
                                completedCount++; // Increment the count for correct answers

                                // Send progress to the server
                                fetch('config/record-quiz-progress.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({
                                        quiz_id: quizId,
                                        completed: completed
                                    })
                                }).then(response => response.json())
                                    .then(data => console.log(data.message))
                                    .catch(error => console.error('Error:', error));

                                // Check if all quizzes are completed
                                if (completedCount === quizItems.length) {
                                    Swal.fire({
                                        title: '🎉 Congratulations!',
                                        text: 'You have successfully completed the lesson!',
                                        icon: 'success',
                                        confirmButtonText: 'Finish'
                                    }).then(() => {
                                        // Optionally redirect or show additional options
                                        console.log('Lesson completed!');
                                    });
                                }
                            }
                        });
                    });
                });
            });
        });

    </script>

    <?php include "base/footer.php"; ?>
</body>

</html>