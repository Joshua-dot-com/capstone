<?php include "config/fetch-subjects.php" ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Subjects</title>
    <?php include "base/header.php" ?>
    <link rel="stylesheet" href="assets/style/css/user-subjects.css">
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php" ?>
        
        <a href="user-index.php?" class="back-button">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>

        <div class="content-wrapper">
            <main class="subject-grid">
                <?php foreach ($subjects as $subject): ?>
                    <a href="user-lessons.php?subject_id=<?php echo $subject['id']; ?>" class="subject-link">
                        <div class="subject-card">
                            <img src="<?php echo $subject['image']; ?>" alt="<?php echo $subject['name']; ?>"
                                class="subject-img">
                            <div class="subject-name"><?php echo $subject['name']; ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </main>
        </div>
    </div>
</body>
<?php include "base/footer.php" ?>

</html>