<?php
$lesson_id = isset($_GET['lesson_id']) ? intval($_GET['lesson_id']) : null;

// Redirect back or show an error if no lesson_id is provided
if (!$lesson_id || !filter_var($lesson_id, FILTER_VALIDATE_INT)) {
    die("Invalid or missing lesson ID. Please specify a valid lesson_id in the URL.");
}

// Fetch word test data for the given lesson_id
include "config/fetch-word-test.php";

$user_id = $_SESSION['id'] ?? null; // Ensure user_id is set in session or replace as needed
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Quiz</title>
    <?php include "base/header.php"; ?>
    <link rel="stylesheet" href="assets/style/css/user-nav.css">
    <link rel="stylesheet" href="assets/style/css/user-word-test.css">
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>

        <!-- Back button with lesson_id parameter to redirect to lessons page -->
        <a href="user-units.php?lesson_id=<?php echo htmlspecialchars($lesson_id); ?>" class="back-button">
            <i class="fas fa-arrow-left"></i> Back to Units
        </a>

        <div class="container-inner">
            <p class="heading">Quiz for Lesson ID: <?php echo htmlspecialchars($lesson_id); ?></p>
            <?php if (isset($error)): ?>
                <p>Error: <?= htmlspecialchars($error); ?></p>
            <?php elseif (isset($word_test) && count($word_test) > 0): ?>
                <div id="quiz-container">
                    <p class="target-word">
                        Say this word: <span id="current-word" style="text-transform: capitalize;"></span>
                    </p>
                    <audio id="word-audio" controls hidden></audio>
                </div>
                <button class="btn play-word">Play Word</button>
                <button class="btn record">
                    <p>Start Listening</p>
                </button>
                <p class="heading">Result:</p>
                <div class="result">
                    <p class="interim"></p>
                </div>
                <button class="btn clear" style="display:none;">New Word</button>
            <?php else: ?>
                <p>No quiz questions available for this lesson.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            <?php if (isset($word_test) && count($word_test) > 0): ?>
                const words = <?= json_encode($word_test); ?>;
            <?php else: ?>
                const words = [];
            <?php endif; ?>

            const playBtn = document.querySelector(".play-word");
            const recordBtn = document.querySelector(".record");
            const clearBtn = document.querySelector(".clear");
            const resultContainer = document.querySelector(".result");
            const wordAudio = document.getElementById("word-audio");
            const currentWordDisplay = document.getElementById("current-word");
            const quizContainer = document.getElementById("quiz-container");

            let SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition,
                recognition,
                recording = false,
                currentWordIndex = -1;

            function loadNewWord() {
                if (words.length > 0) {
                    currentWordIndex = Math.floor(Math.random() * words.length);
                    const wordData = words[currentWordIndex];
                    currentWordDisplay.textContent = wordData.word;
                    wordAudio.src = "../" + wordData.wav_file; // Prepends "../" to the file path
                    quizContainer.style.display = "block";
                } else {
                    alert("No words available for the quiz!");
                }
            }

            function preprocessText(text) {
                // Remove punctuation and trim whitespace
                return text.replace(/[^\w\s]|_/g, "").replace(/\s+/g, " ").toLowerCase().trim();
            }

            function speechToText() {
                try {
                    recognition = new SpeechRecognition();
                    recognition.lang = "en-US";
                    recognition.interimResults = true;
                    recordBtn.classList.add("recording");
                    recordBtn.textContent = "Listening...";
                    recognition.start();

                    recognition.onresult = (event) => {
                        let speechResult = event.results[0][0].transcript;
                        const currentWord = words[currentWordIndex].word;

                        // Preprocess both the recognized speech and the target word
                        speechResult = preprocessText(speechResult);
                        const sanitizedCurrentWord = preprocessText(currentWord);

                        if (event.results[0].isFinal) {
                            resultContainer.innerHTML = `You said: ${speechResult}`;
                            if (speechResult === sanitizedCurrentWord) {
                                resultContainer.innerHTML += "<br>Correct! Well done!";

                                // Record progress for the user
                                recordProgress(words[currentWordIndex].id, 1);
                            } else {
                                resultContainer.innerHTML += `<br>Not quite. The correct word was: ${currentWord}`;
                            }
                        }
                    };

                    recognition.onspeechend = () => stopRecording();
                    recognition.onerror = (event) => {
                        stopRecording();
                        alert(`Error occurred in recognition: ${event.error}`);
                    };
                } catch (error) {
                    console.error(error);
                }
            }

            function recordProgress(wordTestId, completed) {
                // Send an AJAX POST request to record-word-test-progress.php
                $.ajax({
                    url: "config/record-word-test-progress.php", // Backend script URL
                    method: "POST",
                    data: {
                        user_id: <?php echo json_encode($user_id); ?>,
                        word_test_id: wordTestId,
                        completed: completed
                    },
                    dataType: "json", // Expect JSON response from the server
                    success: function (data) {
                        if (data.status === "success") {
                            console.log("Progress recorded successfully.");

                            // Show a congratulatory alert using SweetAlert2
                            Swal.fire({
                                title: "Congratulations!",
                                text: "You have successfully completed this unit! Proceed to Quiz!",
                                icon: "success",
                                confirmButtonText: "OK",
                                allowOutsideClick: false,
                            }).then(() => {
                                // Redirect back to the lessons page
                                window.location.href = `user-quiz.php?lesson_id=${<?php echo json_encode($lesson_id); ?>}`;
                            });
                        } else {
                            console.error("Failed to record progress:", data.message);

                            // Show error alert
                            Swal.fire({
                                title: "Error!",
                                text: data.message || "There was an issue recording your progress. Please try again.",
                                icon: "error",
                                confirmButtonText: "OK",
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error("Error recording progress:", error);

                        // Show error alert for unexpected errors
                        Swal.fire({
                            title: "Error!",
                            text: "An unexpected error occurred. Please try again later.",
                            icon: "error",
                            confirmButtonText: "OK",
                        });
                    }
                });
            }

            function stopRecording() {
                if (recognition) recognition.stop();
                recordBtn.textContent = "Start Listening";
                recordBtn.classList.remove("recording");
                recording = false;
            }

            playBtn.addEventListener("click", () => {
                if (currentWordIndex >= 0) wordAudio.play();
            });

            recordBtn.addEventListener("click", () => {
                if (!recording) {
                    speechToText();
                    recording = true;
                } else {
                    stopRecording();
                }
            });

            clearBtn.addEventListener("click", () => {
                resultContainer.innerHTML = "";
                loadNewWord();
            });

            // Initialize
            loadNewWord();
        });
    </script>

    <?php include "base/footer.php"; ?>
</body>

</html>
