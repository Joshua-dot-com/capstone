<?php
// Include database connection
include '../../config/db.php';

// Query to calculate leaderboard based on 100% completion of subjects
$sql = "
    SELECT 
        users.id AS user_id,
        CONCAT(users.fname, ' ', users.lname) AS user_name,
        COUNT(DISTINCT subjects.subject_id) AS completed_subjects
    FROM users
    LEFT JOIN subjects ON subjects.subject_id IS NOT NULL
    LEFT JOIN lessons ON lessons.subject_id = subjects.subject_id
    LEFT JOIN units ON units.lesson_id = lessons.lesson_id
    LEFT JOIN quizes ON quizes.lesson_id = lessons.lesson_id
    LEFT JOIN word_test ON word_test.lesson_id = lessons.lesson_id
    LEFT JOIN (
        SELECT 
            user_unit_progress.user_id, 
            units.lesson_id, 
            COUNT(units.unit_id) AS total_units, 
            SUM(user_unit_progress.completed) AS completed_units
        FROM user_unit_progress 
        INNER JOIN units ON user_unit_progress.unit_id = units.unit_id
        GROUP BY user_unit_progress.user_id, units.lesson_id
    ) AS unit_progress ON unit_progress.user_id = users.id AND unit_progress.lesson_id = lessons.lesson_id
    LEFT JOIN (
        SELECT 
            user_quiz_progress.user_id, 
            quizes.lesson_id, 
            COUNT(quizes.quiz_id) AS total_quizzes, 
            SUM(user_quiz_progress.completed) AS completed_quizzes
        FROM user_quiz_progress 
        INNER JOIN quizes ON user_quiz_progress.quiz_id = quizes.quiz_id
        GROUP BY user_quiz_progress.user_id, quizes.lesson_id
    ) AS quiz_progress ON quiz_progress.user_id = users.id AND quiz_progress.lesson_id = lessons.lesson_id
    LEFT JOIN (
        SELECT 
            user_word_test_progress.user_id, 
            word_test.lesson_id, 
            COUNT(word_test.id) AS total_word_tests, 
            SUM(user_word_test_progress.completed) AS completed_word_tests
        FROM user_word_test_progress 
        INNER JOIN word_test ON user_word_test_progress.word_test_id = word_test.id
        GROUP BY user_word_test_progress.user_id, word_test.lesson_id
    ) AS word_test_progress ON word_test_progress.user_id = users.id AND word_test_progress.lesson_id = lessons.lesson_id
    WHERE users.user_type = 'user'
    AND (
        COALESCE(unit_progress.completed_units, 0) >= COALESCE(unit_progress.total_units, 0)
        AND COALESCE(quiz_progress.completed_quizzes, 0) >= COALESCE(quiz_progress.total_quizzes, 0)
        AND COALESCE(word_test_progress.completed_word_tests, 0) >= COALESCE(word_test_progress.total_word_tests, 0)
    )
    GROUP BY users.id
    HAVING COUNT(DISTINCT subjects.subject_id) > 0
    ORDER BY completed_subjects DESC";

$result = $conn->query($sql);

// Initialize leaderboard array
$leaderboard = [];
if ($result->num_rows > 0) {
    $rank = 1;
    while ($row = $result->fetch_assoc()) {
        $leaderboard[] = [
            'rank' => $rank,
            'name' => $row['user_name'],
            'score' => $row['completed_subjects']
        ];
        $rank++;
    }
}

// Close the database connection
$conn->close();

// Display leaderboard
foreach ($leaderboard as $entry) {
    echo "Rank: " . $entry['rank'] . ", Name: " . $entry['name'] . ", Completed Subjects: " . $entry['score'] . "<br>";
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartyHub Leaderboards</title>
    <link rel="stylesheet" href="assets/style/css/user-nav.css">

    <style>
        body {
            font-family: 'Comic Sans MS', cursive, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(0deg, rgba(52, 119, 13, 1) 0%, rgba(17, 121, 9, 0.6778361002604167) 14%, rgba(253, 255, 255, 1) 70%);
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        header h1 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 5px;
        }

        header p {
            color: #666;
            margin-bottom: 20px;
        }

        .ranking-table {
            overflow-x: auto;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            background: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 1.1em;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: center;
            color: #333;
        }

        thead th {
            background-color: #4CAF50;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
        }

        tbody tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        tbody tr:nth-child(even) {
            background-color: #eef5f9;
        }

        tbody tr:hover {
            background-color: #e0e7ff;
        }

        .top-rank td {
            font-weight: bold;
            color: #d4af37;
        }

        .top-rank i {
            color: #ffd700;
        }
    </style>
</head>

<body>
    <div class="container">
        <?php include "base/nav-header.php"; ?>
        <div class="leaderboard-container">
            <header>
                <h1>Leaderboard</h1>
            </header>

            <div class="ranking-table">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>User</th>
                            <th>Completed Subjects</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($leaderboard)): ?>
                            <?php foreach ($leaderboard as $user): ?>
                                <tr class="<?= $user['rank'] <= 3 ? 'top-rank' : ''; ?>">
                                    <td><?= htmlspecialchars($user['rank']); ?></td>
                                    <td><?= htmlspecialchars($user['name']); ?></td>
                                    <td><?= htmlspecialchars($user['score']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">No data available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>