<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fun Account Registration</title>
    <?php include "base/header-script.php" ?>
    <link rel="stylesheet" href="assets/style/registration-design.css">
    <style>
        .swal-title {
            font-family: 'Comic Neue', cursive;
            color: #4CAF50;
        }

        .swal-text {
            font-family: 'Comic Neue', cursive;
            color: #333;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="index.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Home</a>

        <div class="register-container">
            <h1>Join the Fun!</h1>

            <div class="img-container">
                <img src="assets/images/welcome_school.png" alt="Welcome Students">
            </div>

            <!-- Added ID to the form -->
            <form action="config/register.php" method="POST" id="registrationForm">
                <div class="form-group">
                    <label for="fname">What's your first name?</label>
                    <input type="text" name="fname" id="fname" class="form-control" placeholder="Your first name" required>
                </div>

                <div class="form-group">
                    <label for="mname">Do you have a middle name? (It's okay if you don't!)</label>
                    <input type="text" name="mname" id="mname" class="form-control" placeholder="Your middle name (if you have one)">
                </div>

                <div class="form-group">
                    <label for="lname">What's your last name?</label>
                    <input type="text" name="lname" id="lname" class="form-control" placeholder="Your last name" required>
                </div>

                <div class="form-group">
                    <label for="bday">When's your birthday?</label>
                    <input type="date" name="bday" id="bday" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="school">What's the name of your school?</label>
                    <input type="text" name="school" id="school" class="form-control" placeholder="Your school's name" required>
                </div>

                <div class="form-group">
                    <label for="email">What's your email address?</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Choose a secret password:</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Your secret password" required>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Type your secret password again:</label>
                    <input type="password" id="confirm_password" class="form-control" placeholder="Confirm your secret password" required>
                </div>

                <input type="submit" value="Let's Go!">
            </form>
        </div>
    </div>
    <?php include "base/footer-script.php" ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const form = document.getElementById('registrationForm');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');

            function validatePassword() {
                if (password.value === confirmPassword.value) {
                    confirmPassword.classList.remove('mismatch');
                    confirmPassword.classList.add('match');
                } else {
                    confirmPassword.classList.remove('match');
                    confirmPassword.classList.add('mismatch');
                }
            }

            password.addEventListener('input', validatePassword);
            confirmPassword.addEventListener('input', validatePassword);

            form.addEventListener('submit', function (e) {
                if (password.value !== confirmPassword.value) {
                    e.preventDefault(); // Prevent form submission
                    Swal.fire({
                        title: 'Oops!',
                        text: 'Your passwords don\'t match. Please try again!',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#4CAF50',
                        background: '#FFF9C4',
                        customClass: {
                            title: 'swal-title',
                            content: 'swal-text'
                        }
                    });
                }
            });
        });
    </script>

</body>

</html>
